"""
mlx_runner.py — Shared MLX model singleton (Qwen2.5-72B).

Load model một lần duy nhất khi process khởi động,
tất cả nodes dùng chung instance này.

Model mặc định: mlx-community/Qwen2.5-72B-Instruct-4bit
  - 72B params dense → chất lượng ngang GPT-4o
  - ~40GB RAM trên M4 Pro 48GB
  - ~3-5 tok/s (chậm hơn 14B nhưng reasoning mạnh hơn nhiều)

Hỗ trợ 2 chế độ inference:
  1. run_inference(): System + User prompt → raw text
  2. run_json_inference(): System + User prompt → parse JSON output
"""

from __future__ import annotations

import json
import inspect
import logging
import os
import re

logger = logging.getLogger(__name__)

# ── Singleton model cache ────────────────────────────────────────────
_model = None
_tokenizer = None
_sampler_param = None


def get_model():
    """
    Trả về (model, tokenizer) MLX đã load.
    Load lần đầu từ HuggingFace → cache vào ~/.cache/huggingface/.
    Các lần sau dùng cache local, không cần internet.
    """
    global _model, _tokenizer
    if _model is None:
        from mlx_lm import load
        model_path = os.getenv("MLX_MODEL", "mlx-community/Qwen2.5-32B-Instruct-4bit")
        logger.info("Loading MLX model: %s", model_path)
        _model, _tokenizer = load(model_path)
        logger.info("MLX model loaded successfully.")
    return _model, _tokenizer


def _make_sampler_compatible(temperature: float):
    """
    Tạo sampler tương thích với nhiều version `mlx_lm`.
    Một số bản dùng `temp`, một số bản dùng `temperature`.
    """
    from mlx_lm.sample_utils import make_sampler

    global _sampler_param
    if _sampler_param is None:
        params = inspect.signature(make_sampler).parameters
        if "temperature" in params:
            _sampler_param = "temperature"
        elif "temp" in params:
            _sampler_param = "temp"
        else:
            _sampler_param = ""

    if _sampler_param == "temperature":
        return make_sampler(temperature=temperature)
    if _sampler_param == "temp":
        return make_sampler(temp=temperature)
    return make_sampler()


def run_inference(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 1000,
    temperature: float = 0.7,
) -> str:
    """
    Chạy inference cơ bản: system + user prompt → raw text.

    Args:
        system_prompt: Vai trò / hướng dẫn cho model
        user_prompt: Nội dung cần xử lý
        max_tokens: Số token tối đa trong response

    Returns:
        Raw string output từ model
    """
    from mlx_lm import generate
    model, tokenizer = get_model()

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    prompt_text = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )

    sampler = _make_sampler_compatible(temperature)
    return generate(
        model,
        tokenizer,
        prompt=prompt_text,
        max_tokens=max_tokens,
        verbose=False,
        sampler=sampler,
    )


def run_json_inference(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 1500,
    temperature: float = 0.1,
) -> dict | list | None:
    """
    Chạy inference và parse kết quả thành JSON.
    Model được hướng dẫn trả về JSON, hàm này trích xuất + parse.

    Nếu model trả về text có chứa JSON block (```json ... ```),
    hàm sẽ tự extract.

    Args:
        system_prompt: Vai trò / hướng dẫn (nên yêu cầu trả JSON)
        user_prompt: Nội dung cần xử lý
        max_tokens: Số token tối đa

    Returns:
        dict/list nếu parse thành công, None nếu thất bại
    """
    raw = run_inference(system_prompt, user_prompt, max_tokens=max_tokens, temperature=temperature)

    # Thử parse trực tiếp
    try:
        return json.loads(raw.strip())
    except json.JSONDecodeError:
        pass

    # Thử extract JSON block từ markdown code fence
    json_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", raw, re.DOTALL)
    if json_match:
        try:
            return json.loads(json_match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # Thử tìm {...} hoặc [...] trong text
    for pattern in [r"\{.*\}", r"\[.*\]"]:
        match = re.search(pattern, raw, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                continue

    logger.warning("Không thể parse JSON từ model output (%d chars)", len(raw))
    logger.debug("Raw output: %s", raw[:500])
    return None
