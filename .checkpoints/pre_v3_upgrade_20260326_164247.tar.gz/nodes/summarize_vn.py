"""
summarize_vn.py — LangGraph node: Tổng hợp daily digest tiếng Việt cho Telegram.

Node này không tự tóm tắt từng bài nữa. Thay vào đó, nó nhận `note_summary_vi`
đã được nén riêng ở node trước và ghép thành một daily digest tự nhiên hơn.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from editorial_guardrails import build_article_grounding, build_safe_digest
from mlx_runner import run_inference

logger = logging.getLogger(__name__)

TELEGRAM_SUMMARY_SYSTEM = """Bạn là managing editor của một sản phẩm AI Daily Digest trả phí.
Dựa trên danh sách tin tức AI/Tech trong ngày (đã được chấm điểm và nén thành short note),
hãy viết MỘT BẢN TIN TỔNG HỢP gửi vào nhóm Telegram của công ty startup AI tại Hà Nội.

Yêu cầu:
1. Dòng đầu tiên phải là tiêu đề HTML theo dạng: <b>AI Daily Brief | dd/mm</b>
2. Mở đầu chỉ 1 câu ngắn, chuyên nghiệp, như brief buổi sáng.
3. Chỉ chọn tối đa 6 tin mạnh nhất để tránh dài và xấu.
4. Mỗi tin phải theo đúng layout sau:
   `1. <b>[emoji] [Type] | [Tiêu đề ngắn]</b>`
   `[1-2 câu ngắn, tối đa 45 từ, bám short note]`
   `<i>[source_domain nếu có] · Điểm X/100 · Độ chắc cao|vừa|thăm dò</i> · <a href="LINK">Đọc thêm</a>`
5. LUÔN chèn link Notion bằng thẻ HTML: <a href="LINK">Đọc thêm</a> ngay cuối dòng meta nếu có link. Đây là BẮT BUỘC.
6. Ưu tiên làm nổi bật tin có điểm cao và liên quan đến Startup/AI Việt Nam.
7. Kết thúc bằng 1 câu kiểu ưu tiên hành động, ví dụ: "Team ưu tiên đọc tin X/Y nếu cần quyết định nhanh trong ngày."
8. Tránh văn phong quảng cáo; giữ giọng điệu ngắn, chắc, thiên về quyết định.
9. Với tin confidence_label=low, phải dùng giọng điệu mềm như "gợi ý", "đáng theo dõi", "tín hiệu thăm dò"; không được khẳng định mạnh.
10. Chỉ dùng ý đã có trong short note, grounding note, fact anchors, unknowns; không tự thêm dữ kiện mới.
11. Không dùng dấu phân cách kiểu `---`.
12. Không in URL thô, không dùng Markdown [text](link), không viết "Đọc thêm (URL)".

KHÔNG dùng Markdown [text](link). Chỉ dùng HTML <a href="...">text</a>.
KHÔNG dùng thẻ <br>. Xuống dòng bằng dòng trống thông thường.
"""


def summarize_vn_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: Dùng LLM viết bản tin từ TẤT CẢ bài đã qua kiểm duyệt.
    Nguồn ưu tiên: final_articles đã có note_summary_vi, sắp xếp giảm dần theo điểm.
    """
    final_articles = state.get("final_articles", [])
    notion_pages = state.get("notion_pages", [])

    # Map title → Notion URL
    notion_map = {}
    for page in notion_pages:
        if isinstance(page, dict):
            notion_map[page.get("title", "")] = page.get("url", "")

    # Fallback cũ nếu final_articles chưa có
    if not final_articles:
        final_articles = state.get("scored_articles", [])

    # Lọc bài qua ngưỡng 30 điểm, sắp xếp theo điểm giảm dần
    qualified = sorted(
        [a for a in final_articles if a.get("total_score", 0) >= 30],
        key=lambda x: x.get("total_score", 0),
        reverse=True,
    )

    # Giới hạn 6 bài để Telegram gọn, đẹp và ít bị cắt
    qualified = qualified[:6]

    if not qualified:
        safe_summary = build_safe_digest(final_articles, notion_pages)
        logger.info("✅ Không có bài qualified, dùng safe digest deterministic.")
        return {"summary_vn": safe_summary}

    # Chuẩn bị nội dung cho LLM
    today_label = datetime.now().strftime("%d/%m")
    prompt_lines = [
        f"Hom nay la: {today_label}",
        "Viet theo format AI Daily Brief va dam bao giong dieu premium.",
        f"Danh sách {len(qualified)} tin tức AI/Tech hôm nay (sắp xếp theo độ liên quan):\n",
    ]

    if qualified:
        for i, a in enumerate(qualified, 1):
            title = a.get("title", "N/A")
            notion_url = notion_map.get(title, "")
            score = a.get("total_score", 0)
            summary = a.get("note_summary_vi", "") or a.get("summary_vi", "")
            ptype = a.get("primary_type", "")
            grounding = build_article_grounding(a)
            a.update(grounding)
            prompt_lines.append(
                f"Tin #{i} [{ptype}] (Điểm: {score}/100)\n"
                f"- Tiêu đề: {title}\n"
                f"- Short note: {summary}\n"
                f"- Type label: {a.get('primary_emoji', '📄')} {ptype}\n"
                f"- Source domain: {a.get('source_domain', '')}\n"
                f"- Confidence: {grounding.get('confidence_label', 'low')}\n"
                f"- Grounding note: {grounding.get('grounding_note', '')}\n"
                f"- Fact anchors:\n{grounding.get('fact_anchors_text', '- Chưa có fact anchor mạnh.')}\n"
                f"- Unknowns:\n{grounding.get('unknowns_text', '- Không có unknown lớn từ metadata.')}\n"
                f"- Link Notion (BẮT BUỘC GẮN VÀO): {notion_url}\n"
            )

    user_prompt = "\n".join(prompt_lines)

    try:
        summary = run_inference(
            TELEGRAM_SUMMARY_SYSTEM,
            user_prompt,
            max_tokens=1500,
            temperature=0.6,
        )
    except Exception as e:
        logger.error("❌ Summarize failed: %s", e)
        summary = build_safe_digest(final_articles, notion_pages)

    # Giữ giới hạn Telegram 4096 ký tự
    if len(summary) > 4000:
        summary = build_safe_digest(final_articles, notion_pages)

    logger.info("✅ LLM Newsletter generated (%d chars, %d bài qualified)", len(summary), len(qualified))
    return {"summary_vn": summary}
