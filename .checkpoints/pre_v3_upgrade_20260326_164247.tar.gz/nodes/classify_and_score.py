"""
classify_and_score.py — LangGraph node: Phân loại + chấm relevance theo vai "editorial triage".

Mục tiêu là để Qwen local đóng vai tương tự một bộ lọc kiểu Claude:
  1. Classify: gán 1 trong 6 Primary Types
  2. Score: chấm 1-100 dựa trên 3 tiêu chí
  3. Decision: quyết định bài nào cần phân tích sâu, bài nào chỉ lưu cơ bản

6 Primary Types:
  🔬 Research    — Nghiên cứu mới, paper, benchmark, thuật toán mới, bài báo công nghệ tốt cho tối ưu AI trên phần cứng nhỏ mà có sức mạnh lớn,...
  🚀 Product     — Ra mắt sản phẩm, tính năng, API mới, mô hình AI mới, các sản phẩm AI mới, các sản phẩm AI thiết bị biên, ...
  💼 Business    — M&A, funding, chiến lược, nhân sự, doanh thu, lợi nhuận, ...
  ⚖️ Policy      — Luật, quy định, đạo đức AI, chính sách,...
  🌍 Society     — Tác động xã hội, văn hóa, giáo dục, ứng dụng AI vào giáo dục, vào xã hội, vào y tế, vào kinh doanh, ...
  🛠️ Practical   — Hướng dẫn, tips, tools, tutorials, ứng dụng AI vào đời sống,...

3 Tiêu chí chấm điểm (mỗi tiêu chí 0-33 điểm, tổng max 100):
  C1. Chất lượng tin: Relevance, Timeliness, Impact, Source credibility, những người đầu ngành nói gì về nó,...
  C2. Phù hợp startup AI: Ứng dụng được vào SME/startup Việt Nam không? Có thể học hỏi được gì từ nó, có thể làm gì với nó, có thể bán cho ai, có thể hợp tác với ai, ...
  C3. Phù hợp dự án hiện tại: AI Agent, Revenue automation, Enterprise mgmt, AI Product general, ...

Output ghi vào state:
  scored_articles: tất cả bài đã classify + score
  top_articles: bài có score >= MIN_DEEP_ANALYSIS_SCORE
  low_score_articles: bài có score thấp
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

# Đảm bảo project root nằm trong sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from mlx_runner import run_json_inference

logger = logging.getLogger(__name__)


STRATEGIC_KEYWORDS = (
    "open-source",
    "open source",
    "dominance",
    "partnership",
    "partners with",
    "market lead",
    "threatens",
    "race",
    "ecosystem",
    "infrastructure",
    "robotics",
    "advisory body",
    "warns",
    "competition",
)

BUSINESS_KEYWORDS = (
    "startup",
    "funding",
    "partnership",
    "partners with",
    "market",
    "competition",
    "competitive",
    "lead",
    "dominance",
    "robotics",
)

SOCIETY_KEYWORDS = (
    "ecosystem",
    "student",
    "students",
    "education",
    "community",
)

# ── Prompt Master cho classify + score ───────────────────────────────
CLASSIFY_SCORE_SYSTEM = """Bạn là Editorial Triage Lead cho một sản phẩm AI Daily Digest trả phí.
Nhiệm vụ: đọc nhanh từng nguồn tin AI/Tech, chấm điểm relevance như một biên tập viên khó tính,
và quyết định bài nào đáng được đưa vào phân tích sâu.

## 6 Primary Types (CHỌN ĐÚNG 1):
- 🔬 Research: Nghiên cứu mới, paper khoa học, benchmark, thuật toán mới
- 🚀 Product: Ra mắt sản phẩm, tính năng mới, API, platform update
- 💼 Business: M&A, funding, chiến lược kinh doanh, tuyển dụng, cạnh tranh
- ⚖️ Policy: Luật pháp, quy định, đạo đức AI, governance
- 🌍 Society: Tác động xã hội, văn hóa, giáo dục, việc làm
- 🛠️ Practical: Hướng dẫn, tips, tools, tutorials, best practices

## 3 Tiêu chí chấm điểm (mỗi tiêu chí 0-33, tổng max 100):

### C1: Chất lượng tin tức (0-33)
- Nguồn đáng tin cậy? (Reuters, TechCrunch, MIT = cao; blog random = thấp)
- Tin mới (24-48h qua) hay cũ?
- Tác động lớn đến ngành AI?
- Có dữ liệu/dẫn chứng cụ thể?
- Tin chiến lược ở nguồn mạnh về cạnh tranh AI, open-source, partnership, đầu tư hạ tầng, hay cảnh báo từ cơ quan lớn phải được xem là impact cao, kể cả khi nội dung đầu vào ngắn.

### C2: Phù hợp startup AI Việt Nam (0-33)
- Startup AI tại Việt Nam có thể ứng dụng/học hỏi?
- Liên quan đến thị trường Đông Nam Á?
- Có cơ hội kinh doanh?

### C3: Phù hợp dự án hiện tại (0-34)
Công ty đang phát triển 4 MVP:
1. AI News Digest (thu thập, phân tích, tổng hợp tin tức AI tự động)
2. AI Revenue Calculator (tính toán doanh thu, truy cập mọi nơi trong công ty)
3. AI Enterprise Management (quản lý toàn bộ công ty)
4. AI Product general (hướng phát triển sản phẩm AI)
- Tin này có giúp cải thiện sản phẩm nào ở trên không?
- Có công nghệ/ý tưởng mới áp dụng được?

## Rules bổ sung:
- Ưu tiên phân loại `Business` nếu bài nói về cạnh tranh thị trường, open-source race, partnership, strategic move, market lead, ecosystem control, hoặc tác động đến vị thế công ty/quốc gia trong ngành.
- Chỉ chọn `Policy` nếu trọng tâm chính là luật, quy định, compliance, governance, an toàn, hoặc can thiệp của cơ quan quản lý.
- Cấp độ phù hợp (relevance_level): High (Tổng C1+C2+C3 >= 70), Medium (40-69), Low (< 40)
- Mức xử lý (analysis_tier):
  - deep: bài đủ mạnh để đầu tư research/thinking sâu
  - basic: nên lưu và đưa vào digest, nhưng không cần research dài
  - skip: tín hiệu yếu, ít giá trị với sản phẩm kinh doanh
- Nếu nguồn mạnh (đặc biệt Reuters/CNBC/Bloomberg/TechCrunch) và chủ đề mang tính chiến lược cấp ngành, mặc định nghiêng về `deep` trừ khi bài quá mỏng hoặc không liên quan AI.
- editorial_angle: 1 câu nói rõ "điểm đáng quan tâm nhất" của bài này dưới góc nhìn người vận hành startup AI
- Tags: Chọn 3-5 từ khóa tiếng Anh miêu tả đúng nhất, viết thường (lowercase)
- KHÔNG TỰ TÍNH TỔNG ĐIỂM trong JSON (bộ phận Python sẽ lo việc tính tổng).
- Không hype. Không dùng ngôn ngữ quảng cáo. Nếu thiếu dữ liệu, nói rõ là thiếu dữ liệu.
- Nếu Content_available=false (thiếu nội dung) hoặc Published_at trống: hạ điểm C1, tránh kết luận mạnh.

## Output: JSON (KHÔNG markdown, KHÔNG giải thích thêm)
{
  "primary_type": "Research|Product|Business|Policy|Society|Practical",
  "primary_emoji": "🔬|🚀|💼|⚖️|🌍|🛠️",
  "c1_score": 0-33,
  "c1_reason": "Giải thích ngắn gọn (1 câu)",
  "c2_score": 0-33,
  "c2_reason": "Giải thích ngắn gọn (1 câu)",
  "c3_score": 0-34,
  "c3_reason": "Giải thích ngắn gọn (1 câu)",
  "summary_vi": "Tóm tắt 2-3 câu bằng tiếng Việt",
  "editorial_angle": "1 câu về điểm đáng quan tâm nhất",
  "analysis_tier": "deep|basic|skip",
  "tags": ["tag1", "tag2", "tag3"],
  "relevance_level": "High|Medium|Low"
}"""

CLASSIFY_SCORE_USER_TEMPLATE = """Phân loại và chấm điểm bài viết sau:

Tiêu đề: {title}
URL: {url}
Nguồn: {source}
Domain: {source_domain}
Published_at (UTC ISO): {published_at}
Age_hours: {age_hours}
Source_verified (heuristic): {source_verified}
Content_available: {content_available}
Nội dung: {content}

{related_context}

Trả về JSON theo format yêu cầu."""


def _build_related_context(article: dict) -> str:
    """
    Nếu bài viết có related_past (từ deduplicate), thêm vào context
    để model biết "đã từng đưa tin chủ đề này".
    """
    related = article.get("related_past", [])
    if not related:
        return ""

    lines = ["Bài viết LIÊN QUAN ĐÃ ĐĂNG trước đó:"]
    for r in related[:3]:
        lines.append(f"  - [{r.get('primary_type', '?')}] {r.get('title', 'N/A')}")
    lines.append("Hãy xem xét: bài mới có điểm gì khác so với bài cũ?")
    return "\n".join(lines)


def _apply_strategic_boost(article: dict[str, Any], min_score: int) -> None:
    """
    Heuristic nhẹ để tránh under-score các tin chiến lược nguồn mạnh.
    Không thay thế model; chỉ kéo lên khi hội đủ tín hiệu rõ ràng.
    """
    domain = str(article.get("source_domain", "")).lower()
    title = str(article.get("title", "")).lower()
    source_tier = str(article.get("source_tier", "")).lower()
    content_available = bool(article.get("content_available", False))

    strategic = any(keyword in title for keyword in STRATEGIC_KEYWORDS)
    strong_source = source_tier == "a" or domain in {"reuters.com", "cnbc.com", "bloomberg.com", "techcrunch.com"}

    if not (strategic and strong_source):
        return

    current_type = str(article.get("primary_type", ""))
    score = int(article.get("total_score", 0) or 0)

    # Kéo `Policy` về `Business` nếu bản chất là cuộc đua/chien luoc thi truong.
    if current_type == "Policy":
        article["primary_type"] = "Business"
        article["primary_emoji"] = "💼"

    # Nguồn mạnh + tín hiệu chiến lược + score đã khá gần ngưỡng thì đẩy lên deep.
    if score >= max(40, min_score - 20):
        article["analysis_tier"] = "deep"
        article["relevance_level"] = "High" if score >= 55 else article.get("relevance_level", "Medium")

        # Nếu content đầy đủ, boost thêm chút để tăng cơ hội vào top list.
        if content_available and score < min_score:
            article["total_score"] = min(min_score, score + 8)


def _normalize_primary_type(article: dict[str, Any]) -> None:
    """
    Heuristic hẹp để sửa type ở một số case biên.
    Giữ minimal để không phá kết quả tier vốn đã ổn.
    """
    title = str(article.get("title", "")).lower()
    current_type = str(article.get("primary_type", "Practical"))
    score = int(article.get("total_score", 0) or 0)
    content_available = bool(article.get("content_available", False))

    # Trang danh mục / landing page thiếu nội dung: ép về Practical để dễ hiểu hơn.
    if not content_available and score <= 15:
        if any(token in title for token in ("cập nhật tin", "bao", "báo", "khoa hoc", "khoa học", "cong nghe", "công nghệ")):
            article["primary_type"] = "Practical"
            article["primary_emoji"] = "🛠️"
            return

    # Ecosystem/community stories nên ưu tiên Society, kể cả có chữ "cạnh tranh".
    if "ecosystem" in title or "hệ sinh thái" in title or "he sinh thai" in title:
        if "startup" not in title and "partnership" not in title and "partners with" not in title:
            article["primary_type"] = "Society"
            article["primary_emoji"] = "🌍"
            return

    # Tin về startup/thi trường/cạnh tranh nên nghiêng về Business.
    if any(keyword in title for keyword in BUSINESS_KEYWORDS):
        article["primary_type"] = "Business"
        article["primary_emoji"] = "💼"
        return

    # Tin về hệ sinh thái / cộng đồng / giáo dục / bối cảnh Việt Nam nên nghiêng về Society.
    if any(keyword in title for keyword in SOCIETY_KEYWORDS):
        if current_type not in {"Product", "Business"} and "startup" not in title and "partnership" not in title and "partners with" not in title:
            article["primary_type"] = "Society"
            article["primary_emoji"] = "🌍"


def classify_and_score_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: phân loại + chấm điểm mỗi bài viết.

    Input: new_articles (từ deduplicate)
    Output: scored_articles, top_articles, low_score_articles
    """
    articles = state.get("new_articles", [])
    if not articles:
        logger.info("📭 Không có bài mới để classify.")
        return {
            "scored_articles": [],
            "top_articles": [],
            "low_score_articles": [],
        }

    min_score = int(os.getenv("MIN_DEEP_ANALYSIS_SCORE", "60"))
    max_top = int(os.getenv("MAX_DEEP_ANALYSIS_ARTICLES", "10"))

    scored = []
    total = len(articles)

    for i, article in enumerate(articles, 1):
        title = article.get("title", "N/A")
        logger.info("🏷️  Classify+Score [%d/%d]: %s", i, total, title[:60])

        related_ctx = _build_related_context(article)
        user_prompt = CLASSIFY_SCORE_USER_TEMPLATE.format(
            title=title,
            url=article.get("url", ""),
            source=article.get("source", "Unknown"),
            source_domain=article.get("source_domain", ""),
            published_at=article.get("published_at", article.get("published", "")),
            age_hours=article.get("age_hours", ""),
            source_verified=article.get("source_verified", False),
            content_available=article.get("content_available", False),
            content=(article.get("content", "") or article.get("snippet", ""))[:3000],
            related_context=related_ctx,
        )

        try:
            result = run_json_inference(
                CLASSIFY_SCORE_SYSTEM,
                user_prompt,
                max_tokens=1000,
                temperature=0.1,
            )

            if result and isinstance(result, dict):
                try:
                    c1 = int(result.get("c1_score", 0) or 0)
                    c2 = int(result.get("c2_score", 0) or 0)
                    c3 = int(result.get("c3_score", 0) or 0)
                except ValueError:
                    c1, c2, c3 = 0, 0, 0
                    
                analysis_tier = str(result.get("analysis_tier", "")).strip().lower()
                if analysis_tier not in {"deep", "basic", "skip"}:
                    projected_total = c1 + c2 + c3
                    if projected_total >= min_score:
                        analysis_tier = "deep"
                    elif projected_total >= 30:
                        analysis_tier = "basic"
                    else:
                        analysis_tier = "skip"

                article.update({
                    "primary_type": result.get("primary_type", "Practical"),
                    "primary_emoji": result.get("primary_emoji", "🛠️"),
                    "c1_score": c1,
                    "c1_reason": str(result.get("c1_reason", "")),
                    "c2_score": c2,
                    "c2_reason": str(result.get("c2_reason", "")),
                    "c3_score": c3,
                    "c3_reason": str(result.get("c3_reason", "")),
                    "total_score": c1 + c2 + c3,
                    "summary_vi": str(result.get("summary_vi", "")),
                    "editorial_angle": str(result.get("editorial_angle", "")),
                    "analysis_tier": analysis_tier,
                    "tags": result.get("tags", []) if isinstance(result.get("tags"), list) else [],
                    "relevance_level": str(result.get("relevance_level", "Low")),
                })
                _apply_strategic_boost(article, min_score)
                _normalize_primary_type(article)
            else:
                logger.warning("⚠️ Model không trả JSON cho '%s'", title[:40])
                article.update({
                    "primary_type": "Practical",
                    "primary_emoji": "🛠️",
                    "total_score": 0,
                    "summary_vi": "",
                    "analysis_tier": "skip",
                })
        except Exception as e:
            logger.error("❌ Classify failed: '%s': %s", title[:40], e)
            article.update({
                "primary_type": "Practical",
                "primary_emoji": "🛠️",
                "total_score": 0,
                "analysis_tier": "skip",
            })

        scored.append(article)

    # Sắp xếp theo score giảm dần
    scored.sort(key=lambda a: a.get("total_score", 0), reverse=True)

    # Tách top articles vs low score
    top = [
        a for a in scored
        if a.get("total_score", 0) >= min_score or a.get("analysis_tier") == "deep"
    ][:max_top]
    low = [a for a in scored if a not in top]

    logger.info(
        "✅ Classify+Score xong: %d bài → %d top (≥%d) + %d low",
        len(scored), len(top), min_score, len(low)
    )

    return {
        "scored_articles": scored,
        "top_articles": top,
        "low_score_articles": low,
    }
