"""
save_notion.py — LangGraph node: Lưu bài viết vào Notion Database.

Tạo 1 page Notion cho MỖI bài viết (không phải 1 page chung).
Mỗi page có đầy đủ 13 properties theo schema MVP2.

Đồng thời lưu vào ChromaDB memory để Agent nhớ dài hạn.

Properties Notion:
  1.  Name (Title) → emoji + tiêu đề
  2.  Type (Select) → 6 Primary Types
  3.  Created time (Date) → auto
  4.  Link gốc (URL)
  5.  Score (Number 1-100)
  6.  Tiêu chí chọn tin (Rich Text) → C1 reason
  7.  Mức độ phù hợp dự án (Select: High/Medium/Low)
  8.  Hệ đánh giá dự án (Rich Text) → C2 + C3 reason
  9.  Tổng hợp phân tích (Rich Text) → content_page_md / deep_analysis
  10. Recommend idea (Rich Text)
  11. Summarize (Rich Text) → note_summary_vi
  12. Tag (Multi-select)
  13. Status (Status)
"""

from __future__ import annotations

import hashlib
import logging
import os
import sys
import unicodedata
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import save_article
from editorial_guardrails import build_article_grounding
from memory import store_article

logger = logging.getLogger(__name__)


PROPERTY_ALIASES: dict[str, list[tuple[str, str]]] = {
    "title": [("Name", "title")],
    "type": [("Type", "select"), ("Loại tin", "select"), ("Loai tin", "select")],
    "url": [("Link gốc", "url"), ("Link goc", "url"), ("Link", "url"), ("URL", "url")],
    "score": [("Score", "number"), ("Điểm", "number"), ("Diem", "number")],
    "summary": [("Summarize", "rich_text"), ("Summary", "rich_text"), ("Tóm tắt", "rich_text"), ("Tom tat", "rich_text")],
    "recommend": [("Recommend idea", "rich_text"), ("Recommendation", "rich_text"), ("Khuyến nghị", "rich_text"), ("Khuyen nghi", "rich_text")],
    "tags": [("Tag", "multi_select"), ("Tags", "multi_select")],
    "relevance": [("Mức độ phù hợp", "select"), ("Muc do phu hop", "select"), ("Relevance", "select")],
    "project_fit": [("Mức độ phù hợp dự án", "select"), ("Muc do phu hop du an", "select"), ("Project fit", "select")],
    "selection_reason": [("Tiêu chí chọn tin", "rich_text"), ("Tieu chi chon tin", "rich_text")],
    "evaluation": [("Hệ đánh giá dự án", "rich_text"), ("He danh gia du an", "rich_text")],
    "analysis": [("Tổng hợp phân tích", "rich_text"), ("Tong hop phan tich", "rich_text"), ("Analysis", "rich_text")],
    "status": [("Status", "status")],
}


def _truncate(text: str, max_len: int = 2000) -> str:
    """Cắt text cho Notion API (limit 2000 chars/block)."""
    if not text:
        return ""
    return text[:max_len]


def _normalize_property_name(name: str) -> str:
    ascii_name = unicodedata.normalize("NFKD", str(name or "")).encode("ascii", "ignore").decode("ascii")
    return "".join(ch for ch in ascii_name.lower() if ch.isalnum())


def _resolve_property_name(
    database_properties: dict[str, Any],
    aliases: list[tuple[str, str]],
) -> str | None:
    normalized_map = {
        _normalize_property_name(name): (name, prop)
        for name, prop in database_properties.items()
        if isinstance(prop, dict)
    }

    for alias, expected_type in aliases:
        match = normalized_map.get(_normalize_property_name(alias))
        if match and match[1].get("type") == expected_type:
            return match[0]

    for alias, expected_type in aliases:
        alias_norm = _normalize_property_name(alias)
        for normalized_name, (actual_name, prop) in normalized_map.items():
            if prop.get("type") == expected_type and (alias_norm in normalized_name or normalized_name in alias_norm):
                return actual_name

    return None


def _resolve_property_map(database_properties: dict[str, Any]) -> dict[str, str]:
    resolved: dict[str, str] = {}
    for semantic_key, aliases in PROPERTY_ALIASES.items():
        actual_name = _resolve_property_name(database_properties, aliases)
        if actual_name:
            resolved[semantic_key] = actual_name
    return resolved


def _project_fit_level(c3_score: int) -> str:
    if c3_score >= 24:
        return "High"
    if c3_score >= 12:
        return "Medium"
    return "Low"


def _append_text_blocks(children: list[dict[str, Any]], heading: str, items: list[str]) -> None:
    """Append a simple heading + paragraph blocks for short evidence lists."""
    if not items:
        return

    children.append({
        "object": "block",
        "type": "heading_2",
        "heading_2": {
            "rich_text": [{"type": "text", "text": {"content": heading}}]
        },
    })

    for item in items[:5]:
        children.append({
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [{"type": "text", "text": {"content": _truncate(f"- {item}")}}]
            },
        })


def _get_database_properties(notion, database_id: str) -> dict[str, Any]:
    """Đọc schema của database để chỉ set những property thực sự tồn tại."""
    try:
        database = notion.databases.retrieve(database_id=database_id)
    except Exception as e:
        logger.warning("⚠️ Không đọc được schema database Notion: %s", e)
        return {}
    return database.get("properties", {}) if isinstance(database, dict) else {}


def _create_notion_page(
    notion,
    database_id: str,
    article: dict[str, Any],
    database_properties: dict[str, Any],
) -> str | None:
    """
    Tạo 1 page Notion cho 1 bài viết.
    Trả về URL page nếu thành công, None nếu lỗi.
    """
    emoji = article.get("primary_emoji", "📄")
    title = article.get("title", "Untitled")
    ptype = article.get("primary_type", "Practical")
    url = article.get("url", "")
    score = article.get("total_score", 0)
    summary_vi = article.get("summary_vi", "")
    note_summary_vi = article.get("note_summary_vi", "")
    deep_analysis = article.get("content_page_md") or article.get("deep_analysis", "")
    recommend = article.get("recommend_idea", "")
    relevance = article.get("relevance_level", "Low")
    tags = article.get("tags", [])
    c1_reason = article.get("c1_reason", "")
    c2_reason = article.get("c2_reason", "")
    c3_reason = article.get("c3_reason", "")
    c3_score = int(article.get("c3_score", 0) or 0)
    source = article.get("source", "")
    source_domain = article.get("source_domain", "")
    published_at = article.get("published_at", article.get("published", ""))
    source_verified = article.get("source_verified", False)
    source_tier = article.get("source_tier", "unknown")
    age_hours = article.get("age_hours", None)
    grounding = article if article.get("grounding_note") else build_article_grounding(article)
    confidence_label = grounding.get("confidence_label", "low")
    grounding_note = grounding.get("grounding_note", "")
    fact_anchors = grounding.get("fact_anchors", [])
    reasonable_inferences = grounding.get("reasonable_inferences", [])
    unknowns = grounding.get("unknowns", [])
    project_fit_level = _project_fit_level(c3_score)
    property_map = _resolve_property_map(database_properties)

    # Hệ đánh giá: gộp C2 + C3
    he_danh_gia = ""
    if c2_reason:
        he_danh_gia += f"Startup VN: {c2_reason}\n"
    if c3_reason:
        he_danh_gia += f"Dự án hiện tại: {c3_reason}"

    # Properties cho Notion
    properties = {
        property_map.get("title", "Name"): {
            "title": [{"text": {"content": f"{emoji} {title}"[:100]}}]
        },
    }

    # Type (Select) — chỉ thêm nếu Notion DB đã có property này
    type_prop = property_map.get("type")
    if ptype and type_prop:
        properties[type_prop] = {"select": {"name": ptype}}

    # Link gốc (URL)
    url_prop = property_map.get("url")
    if url and url_prop:
        properties[url_prop] = {"url": url}

    # Score (Number)
    score_prop = property_map.get("score")
    if score_prop:
        properties[score_prop] = {"number": score}

    relevance_prop = property_map.get("relevance")
    if relevance and relevance_prop:
        properties[relevance_prop] = {"select": {"name": relevance}}

    project_fit_prop = property_map.get("project_fit")
    if project_fit_prop:
        properties[project_fit_prop] = {"select": {"name": project_fit_level}}

    # Tag (Multi-select)
    tags_prop = property_map.get("tags")
    if tags and tags_prop:
        properties[tags_prop] = {
            "multi_select": [{"name": t[:50]} for t in tags[:5]]
        }

    # Rich text properties — chỉ set nếu DB thực sự có schema tương ứng
    summary_prop = property_map.get("summary")
    if note_summary_vi and summary_prop:
        properties[summary_prop] = {
            "rich_text": [{"type": "text", "text": {"content": _truncate(note_summary_vi)}}]
        }

    selection_reason_prop = property_map.get("selection_reason")
    if c1_reason and selection_reason_prop:
        properties[selection_reason_prop] = {
            "rich_text": [{"type": "text", "text": {"content": _truncate(c1_reason)}}]
        }

    evaluation_prop = property_map.get("evaluation")
    if he_danh_gia and evaluation_prop:
        properties[evaluation_prop] = {
            "rich_text": [{"type": "text", "text": {"content": _truncate(he_danh_gia)}}]
        }

    analysis_prop = property_map.get("analysis")
    if deep_analysis and analysis_prop:
        properties[analysis_prop] = {
            "rich_text": [{"type": "text", "text": {"content": _truncate(deep_analysis)}}]
        }

    recommend_prop = property_map.get("recommend")
    if recommend and recommend_prop:
        properties[recommend_prop] = {
            "rich_text": [{"type": "text", "text": {"content": _truncate(recommend)}}]
        }

    # Children blocks (nội dung page)
    children = []

    source_snapshot = []
    if source:
        source_snapshot.append(f"Nguồn: {source}")
    if source_domain:
        source_snapshot.append(f"Domain: {source_domain}")
    if published_at:
        source_snapshot.append(f"Published: {published_at}")
    if age_hours is not None:
        source_snapshot.append(f"Age: {age_hours}h")
    source_snapshot.append(f"Verified heuristic: {'yes' if source_verified else 'no'}")
    source_snapshot.append(f"Tier: {source_tier.upper()}")

    children.append({
        "object": "block",
        "type": "callout",
        "callout": {
            "icon": {"type": "emoji", "emoji": "🧭"},
            "rich_text": [{
                "type": "text",
                "text": {"content": _truncate(" | ".join(source_snapshot), 1800)},
            }],
        },
    })

    children.append({
        "object": "block",
        "type": "callout",
        "callout": {
            "icon": {"type": "emoji", "emoji": "🔎"},
            "rich_text": [{
                "type": "text",
                "text": {
                    "content": _truncate(
                        f"Grounding: {grounding_note} | Confidence: {confidence_label.upper()}",
                        1800,
                    )
                },
            }],
        },
    })

    _append_text_blocks(children, "✅ Fact Anchors", fact_anchors)
    _append_text_blocks(children, "🧠 Reasonable Inferences", reasonable_inferences)
    _append_text_blocks(children, "❓ Unknown / Need Verification", unknowns)

    # Tóm tắt
    if note_summary_vi:
        children.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"type": "text", "text": {"content": "📝 Note tóm tắt"}}]
            },
        })
        children.append({
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [{"type": "text", "text": {"content": _truncate(note_summary_vi)}}]
            },
        })

    if summary_vi:
        children.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"type": "text", "text": {"content": "📌 Tóm tắt nguồn"}}]
            },
        })
        children.append({
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [{"type": "text", "text": {"content": _truncate(summary_vi)}}]
            },
        })

    # Tiêu chí chọn tin
    if c1_reason:
        children.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"type": "text", "text": {"content": "📊 Tiêu chí chọn tin"}}]
            },
        })
        children.append({
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [{"type": "text", "text": {"content": _truncate(c1_reason)}}]
            },
        })

    # Hệ đánh giá dự án
    if he_danh_gia:
        children.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"type": "text", "text": {"content": "🎯 Hệ đánh giá dự án"}}]
            },
        })
        children.append({
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [{"type": "text", "text": {"content": _truncate(he_danh_gia)}}]
            },
        })

    # Phân tích sâu
    if deep_analysis:
        children.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"type": "text", "text": {"content": "🔬 Tổng hợp phân tích"}}]
            },
        })
        # Chia nhỏ nếu dài > 2000 chars
        for chunk_start in range(0, len(deep_analysis), 2000):
            chunk = deep_analysis[chunk_start:chunk_start + 2000]
            children.append({
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": chunk}}]
                },
            })

    # Recommend idea
    if recommend:
        children.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"type": "text", "text": {"content": "💡 Recommend Idea"}}]
            },
        })
        for chunk_start in range(0, len(recommend), 2000):
            chunk = recommend[chunk_start:chunk_start + 2000]
            children.append({
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": chunk}}]
                },
            })

    # Score breakdown
    children.append({
        "object": "block",
        "type": "callout",
        "callout": {
            "icon": {"type": "emoji", "emoji": "📊"},
            "rich_text": [{
                "type": "text",
                "text": {"content": f"Score: {score}/100 | C1: {article.get('c1_score', 0)} | C2: {article.get('c2_score', 0)} | C3: {article.get('c3_score', 0)}"},
            }],
        },
    })

    # Limit to 100 blocks
    children = children[:100]

    try:
        page = notion.pages.create(
            parent={"database_id": database_id},
            properties=properties,
            children=children,
        )
        return page.get("url", "")
    except Exception as e:
        logger.error("❌ Notion page failed for '%s': %s", title[:40], e)
        return None


def save_notion_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: lưu tất cả bài vào Notion + ChromaDB memory.

    Input:
        analyzed_articles: bài đã phân tích sâu (top)
        low_score_articles: bài score thấp (lưu cơ bản)
        scored_articles: fallback nếu không có analyzed

    Output:
        notion_pages: list {title, url} cho summarize_vn
    """
    notion_token = os.getenv("NOTION_TOKEN")
    database_id = os.getenv("NOTION_DATABASE_ID")

    # ── Thu thập tất cả bài cần lưu ────────────────────────────────
    all_articles = list(state.get("final_articles", []))

    if not all_articles:
        analyzed = state.get("analyzed_articles", [])
        low_score = state.get("low_score_articles", [])
        all_articles = analyzed + low_score

    # Fallback: nếu không có analyzed, lấy scored
    if not all_articles:
        all_articles = state.get("scored_articles", [])

    if not all_articles:
        logger.info("📭 Không có bài nào để lưu.")
        return {"notion_pages": []}

    notion_pages = []
    notion_available = bool(notion_token and database_id)
    database_properties: dict[str, Any] = {}
    property_map: dict[str, str] = {}

    if notion_available:
        from notion_client import Client
        notion = Client(auth=notion_token)
        database_properties = _get_database_properties(notion, database_id)
        property_map = _resolve_property_map(database_properties)
        missing_fields = [field for field in ("url", "score", "summary", "recommend", "type", "relevance", "project_fit", "tags") if field not in property_map]
        if missing_fields:
            logger.warning(
                "⚠️ Notion DB thiếu hoặc lệch tên/type cho các cột: %s",
                ", ".join(missing_fields),
            )
    else:
        logger.warning("⚠️ Notion credentials chưa cấu hình — chỉ lưu vào memory.")
        notion = None

    for article in all_articles:
        title = article.get("title", "N/A")
        url = article.get("url", "")
        url_hash = hashlib.sha256(url.encode()).hexdigest()[:16]

        # ── Lưu Notion (nếu có) ──────────────────────────────────
        notion_url = ""
        if notion and notion_available:
            notion_url = _create_notion_page(
                notion,
                database_id,
                article,
                database_properties,
            ) or ""
            if notion_url:
                logger.info("✅ Notion: '%s' → %s", title[:40], notion_url)

        notion_pages.append({"title": title, "url": notion_url})

        # ── Lưu SQLite (dedup history) ────────────────────────────
        save_article(
            url=url,
            title=title,
            source=article.get("source", ""),
            primary_type=article.get("primary_type", ""),
            summary=article.get("note_summary_vi", "") or article.get("summary_vi", ""),
            full_content=article.get("content_page_md", "") or article.get("deep_analysis", ""),
            relevance_score=article.get("total_score", 0),
        )

        # ── Lưu ChromaDB memory (long-term knowledge) ────────────
        store_article(
            article_id=url_hash,
            title=title,
            summary=article.get("note_summary_vi", "") or article.get("summary_vi", ""),
            primary_type=article.get("primary_type", ""),
            score=article.get("total_score", 0),
            url=url,
        )

    logger.info("✅ Saved %d articles (Notion: %s, Memory: ✅, SQLite: ✅)",
                len(all_articles), "✅" if notion_available else "⏭️")

    return {"notion_pages": notion_pages}
