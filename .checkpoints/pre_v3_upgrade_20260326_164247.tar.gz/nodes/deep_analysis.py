"""
deep_analysis.py — LangGraph node: Phân tích sâu bài top score theo vai "research + thinking".

Node này mô phỏng kiểu làm việc của ChatGPT research/thinking nhưng chạy local bằng Qwen:
  1. Tìm thêm tín hiệu cộng đồng / tin bổ sung
  2. Đối chiếu với lịch sử trong memory
  3. Viết một bản phân tích dài, có thể dùng trực tiếp làm content page trong Notion

Output:
  - deep_analysis: nội dung phân tích dài
  - content_page_md: alias của deep_analysis để downstream dùng rõ nghĩa hơn
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

# Đảm bảo project root nằm trong sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from editorial_guardrails import build_article_grounding
from mlx_runner import run_inference

logger = logging.getLogger(__name__)


# ── Search cộng đồng ─────────────────────────────────────────────────

def _search_community_reactions(keyword: str) -> str:
    """
    Tìm kiếm phản ứng cộng đồng về 1 chủ đề qua DuckDuckGo.
    Tìm trên Reddit, Hacker News, các forum AI.

    Args:
        keyword: Từ khóa tìm kiếm (thường là tên sản phẩm/sự kiện)

    Returns:
        Tóm tắt text các bài viết/bình luận tìm được
    """
    try:
        from ddgs import DDGS
    except ImportError:
        logger.warning("ddgs not available, skipping community search")
        return ""

    results_text = []

    # Tìm trên Reddit
    try:
        with DDGS() as ddgs:
            reddit_results = list(ddgs.text(
                f"site:reddit.com {keyword}",
                max_results=3,
            ))
            for r in reddit_results:
                results_text.append(
                    f"[Reddit] {r.get('title', '')}: {r.get('body', '')[:300]}"
                )
    except Exception as e:
        logger.debug("Reddit search failed: %s", e)

    # Tìm tin tức bổ sung
    try:
        with DDGS() as ddgs:
            news_results = list(ddgs.news(
                keyword,
                max_results=3,
            ))
            for r in news_results:
                results_text.append(
                    f"[News] {r.get('title', '')}: {r.get('body', '')[:300]}"
                )
    except Exception as e:
        logger.debug("News search failed: %s", e)

    # Tìm trên Hacker News
    try:
        with DDGS() as ddgs:
            hn_results = list(ddgs.text(
                f"site:news.ycombinator.com {keyword}",
                max_results=2,
            ))
            for r in hn_results:
                results_text.append(
                    f"[HackerNews] {r.get('title', '')}: {r.get('body', '')[:300]}"
                )
    except Exception as e:
        logger.debug("HackerNews search failed: %s", e)

    return "\n".join(results_text) if results_text else ""


# ── Prompt phân tích sâu ─────────────────────────────────────────────

DEEP_ANALYSIS_SYSTEM = """Bạn là Principal Research Analyst cho một sản phẩm AI Daily Digest dùng trong vận hành doanh nghiệp.
Bạn không chỉ tóm tắt tin, mà phải biến tin thành quyết định: điều gì là thật, điều gì đáng quan tâm,
giá trị thực tế là gì, và với người làm sản phẩm/doanh nghiệp thì nên nhìn tin này theo lăng kính nào.

Hãy viết một bản content page bằng tiếng Việt, súc tích nhưng giàu ý, theo cấu trúc sau:

## Executive Note
- Mở đầu bằng 1 đoạn ngắn kiểu "điều này có nghĩa gì trong thực tế"
- Nêu bản chất tin + giá trị thực tế + điều kiện/giới hạn quan trọng nhất

## Source Snapshot
- Tóm tắt nhanh nguồn, độ tin cậy, thời điểm, và vì sao nên/không nên tin mạnh

## What Happened
- Tin này thực chất đang nói điều gì?
- Điều gì là mới, khác, hoặc đáng chú ý nhất?

## Why It Matters
- Giá trị thực tế với founder/PM/operator/team AI là gì?
- Trường hợp nào bài này hữu ích thật, trường hợp nào chỉ mang tính trình diễn?

## Evidence And Caveats
- Độ mạnh của nguồn và bằng chứng
- Phần nào là fact, phần nào mới là claim/marketing
- Nếu thiếu dữ liệu, nói rõ là thiếu
- BẮT BUỘC có đúng 3 tiểu mục con:
  ### Fact Anchors
  ### Reasonable Inferences
  ### Unknown / Need Verification

## Market Reaction
- Tóm tắt phản ứng từ dữ liệu được cung cấp
- Nếu không có dữ liệu cộng đồng, ghi rõ "Chưa có dữ liệu cộng đồng"

## Action For Us
- Điều kiện để áp dụng
- Rủi ro, chi phí, giới hạn, hoặc friction khi triển khai
- Team nên theo dõi, thử nhanh, hay bỏ qua?

## Recommendation
- Kết luận ngắn, thẳng, không marketing
- Chỉ ra đây là cơ hội đáng hành động, nên theo dõi thêm, hay chỉ nên tham khảo

Quy tắc:
- Tuyệt đối không bịa dữ liệu hoặc phản ứng cộng đồng.
- Không dùng giọng điệu cường điệu.
- Ưu tiên insight thực tế hơn là kể lại nội dung nguồn.
- Nếu có bài cũ liên quan, dùng để chỉ ra bối cảnh và mức độ mới của tin.

Độ dài mục tiêu: 450-700 từ."""

DEEP_ANALYSIS_USER_TEMPLATE = """Phân tích sâu bài viết sau để dùng làm content page:

Tiêu đề: {title}
Type: {primary_type}
Score: {total_score}/100
Editorial angle: {editorial_angle}
URL: {url}
Source: {source}
Source domain: {source_domain}
Published_at (UTC ISO): {published_at}
Source_verified (heuristic): {source_verified}
Source_tier: {source_tier}
Grounding note: {grounding_note}
Fact anchors:
{fact_anchors}
Reasonable inferences:
{reasonable_inferences}
Unknown / need verification:
{unknowns}
Nội dung gốc: {content}

--- PHẢN ỨNG CỘNG ĐỒNG (từ internet search) ---
{community_reactions}

--- BÀI CŨ LIÊN QUAN (từ memory) ---
{related_past}

Hãy viết content page theo cấu trúc yêu cầu."""


def _ensure_evidence_sections(analysis: str, grounding: dict[str, Any]) -> str:
    """Append deterministic evidence sections when the model omits them."""
    required_markers = (
        "### Fact Anchors",
        "### Reasonable Inferences",
        "### Unknown / Need Verification",
    )
    if all(marker in analysis for marker in required_markers):
        return analysis

    appendix = (
        "\n\n## Evidence And Caveats\n"
        "### Fact Anchors\n"
        f"{grounding.get('fact_anchors_text', '- Chưa có fact anchor mạnh.')}\n\n"
        "### Reasonable Inferences\n"
        f"{grounding.get('reasonable_inferences_text', '- Không có suy luận bổ sung.')}\n\n"
        "### Unknown / Need Verification\n"
        f"{grounding.get('unknowns_text', '- Không có unknown lớn từ metadata.')}"
    )
    return analysis.rstrip() + appendix


def deep_analysis_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: phân tích sâu cho top articles.

    Input: top_articles (từ classify_and_score, score >= 60)
    Output: analyzed_articles (top articles + deep_analysis field)
    """
    top_articles = state.get("top_articles", [])
    if not top_articles:
        logger.info("📭 Không có bài đủ điểm để phân tích sâu.")
        return {"analyzed_articles": []}

    analyzed = []
    total = len(top_articles)

    for i, article in enumerate(top_articles, 1):
        title = article.get("title", "N/A")
        logger.info("🔬 Deep Analysis [%d/%d]: %s", i, total, title[:60])

        # ── Bước 1: Tìm phản ứng cộng đồng ────────────────────────
        keyword = title.split(" – ")[0].split(" | ")[0][:80]
        community = _search_community_reactions(keyword)
        if community:
            logger.info("   📡 Tìm thấy %d dòng phản ứng cộng đồng", community.count("\n") + 1)
        else:
            community = "Chưa có dữ liệu cộng đồng"

        # ── Bước 2: Context bài cũ liên quan (từ memory) ───────────
        related = article.get("related_past", [])
        related_text = ""
        if related:
            lines = []
            for r in related[:3]:
                lines.append(f"- [{r.get('primary_type', '?')}] {r.get('title', 'N/A')} (score: {r.get('score', 0)})")
            related_text = "\n".join(lines)
        else:
            related_text = "(Không có bài cũ cùng chủ đề trong memory)"

        article["community_reactions"] = community
        grounding = build_article_grounding(article)
        article.update(grounding)

        # ── Bước 3: LLM phân tích sâu ──────────────────────────────
        user_prompt = DEEP_ANALYSIS_USER_TEMPLATE.format(
            title=title,
            primary_type=article.get("primary_type", "Unknown"),
            total_score=article.get("total_score", 0),
            editorial_angle=article.get("editorial_angle", "N/A"),
            url=article.get("url", ""),
            source=article.get("source", "Unknown"),
            source_domain=article.get("source_domain", ""),
            published_at=article.get("published_at", article.get("published", "")),
            source_verified=article.get("source_verified", False),
            source_tier=article.get("source_tier", "unknown"),
            grounding_note=grounding.get("grounding_note", ""),
            fact_anchors=grounding.get("fact_anchors_text", "- Chưa có fact anchor mạnh."),
            reasonable_inferences=grounding.get("reasonable_inferences_text", "- Không có suy luận bổ sung."),
            unknowns=grounding.get("unknowns_text", "- Không có unknown lớn từ metadata."),
            content=(article.get("content", "") or article.get("snippet", ""))[:3000],
            community_reactions=community[:2000],
            related_past=related_text,
        )

        try:
            analysis = run_inference(
                DEEP_ANALYSIS_SYSTEM,
                user_prompt,
                max_tokens=2200,
                temperature=0.3,
            )
            analysis = _ensure_evidence_sections(analysis, grounding)
            article["deep_analysis"] = analysis
            article["content_page_md"] = analysis
            logger.info("   ✅ Phân tích xong (%d chars)", len(analysis))
        except Exception as e:
            logger.error("   ❌ Deep analysis failed: %s", e)
            article["deep_analysis"] = "Không thể phân tích sâu — lỗi hệ thống."
            article["content_page_md"] = article["deep_analysis"]

        analyzed.append(article)

    logger.info("✅ Deep Analysis hoàn tất: %d bài", len(analyzed))
    return {"analyzed_articles": analyzed}
