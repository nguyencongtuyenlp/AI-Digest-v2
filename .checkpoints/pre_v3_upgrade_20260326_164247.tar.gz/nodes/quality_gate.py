"""
quality_gate.py - Final summary sanity gate before Telegram.

If the LLM summary fails deterministic checks, fall back to a safe digest built
from already-grounded article metadata.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from editorial_guardrails import build_safe_digest, validate_telegram_summary

logger = logging.getLogger(__name__)


def quality_gate_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    Validate `summary_vn` before it is sent to Telegram.
    """
    final_articles = list(state.get("final_articles", []))
    notion_pages = list(state.get("notion_pages", []))
    summary = str(state.get("summary_vn", "") or "")

    warnings = validate_telegram_summary(summary, final_articles, notion_pages)
    if warnings or not summary.strip():
        safe_summary = build_safe_digest(final_articles, notion_pages)
        logger.warning("⚠️ Quality gate fallback activated: %s", ", ".join(warnings) or "empty_summary")
        return {
            "summary_vn": safe_summary,
            "summary_mode": "safe_fallback",
            "summary_warnings": warnings or ["empty_summary"],
        }

    logger.info("✅ Quality gate passed with LLM summary.")
    return {
        "summary_vn": summary,
        "summary_mode": "llm_passed",
        "summary_warnings": [],
    }
