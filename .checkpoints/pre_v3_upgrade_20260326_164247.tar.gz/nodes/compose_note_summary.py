"""
compose_note_summary.py — LangGraph node: Nén mỗi bài thành short note chuyên dùng cho delivery.

Node này giúp tách rõ:
  - content_page_md / deep_analysis: bản phân tích dài cho Notion page
  - note_summary_vi: bản nén 1 đoạn cho property Notion + Telegram preview
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from editorial_guardrails import build_article_grounding
from mlx_runner import run_inference

logger = logging.getLogger(__name__)

NOTE_SUMMARY_SYSTEM = """Bạn là biên tập viên cho một sản phẩm AI Daily Digest.
Nhiệm vụ: nén một bài phân tích thành đúng 1 đoạn tóm tắt ngắn, sắc, và hữu ích cho người bận rộn,
đúng chuẩn "Executive Note" của sản phẩm.

Yêu cầu bắt buộc:
- Viết bằng tiếng Việt.
- Bắt đầu đúng bằng cụm: "Ý chính của tin này là:"
- Chỉ 1 đoạn, không bullet, không markdown.
- Độ dài mục tiêu: 55-95 từ.
- Phải nêu được 3 ý trong cùng một đoạn:
  1. Bản chất của tin là gì
  2. Giá trị thực tế với người làm sản phẩm/doanh nghiệp là gì
  3. Giới hạn, điều kiện, hoặc điểm cần thận trọng
- Chỉ được dùng thông tin có trong bài phân tích, grounding note, fact anchors, và metadata nguồn.
- Không được biến inference thành fact; nếu dữ liệu yếu phải nói thẳng là dữ liệu yếu.
- Không lặp lại nguyên tiêu đề.
- Không hype, không giật tít, không nói chung chung.
- Ưu tiên câu ngắn, rõ, không dùng quá nhiều tính từ.
- Chỉ nói "tín hiệu yếu" khi score < 30 hoặc source yếu.
- Nếu score >= 60 thì kết thúc bằng câu hướng hành động/ưu tiên theo dõi, không gọi là "tín hiệu yếu".
- Nếu là `category/landing page` (không có bài cụ thể) thì phải nói rõ "đây là trang danh mục, giá trị thấp".
- Tránh khuyến nghị hành động mạnh khi chỉ có mô tả chung chung.
- Nếu kết luận yếu, phải dùng câu đầy đủ: "Đây là tín hiệu yếu, nên chỉ theo dõi."
"""

NOTE_SUMMARY_USER_TEMPLATE = """Hãy nén bài sau thành short note:

Tiêu đề: {title}
Type: {primary_type}
Score: {total_score}/100
Editorial angle: {editorial_angle}
Tóm tắt ngắn hiện có: {summary_vi}
Source verified: {source_verified}
Source tier: {source_tier}
Content available: {content_available}
Confidence label: {confidence_label}
Grounding note: {grounding_note}
Fact anchors:
{fact_anchors}
Reasonable inferences:
{reasonable_inferences}
Unknown / need verification:
{unknowns}

Phân tích dài:
{analysis}
"""


def _fallback_note(article: dict[str, Any]) -> str:
    """Fallback an toàn nếu model lỗi hoặc trả text quá tệ."""
    grounding = article if article.get("grounding_note") else build_article_grounding(article)
    summary = (article.get("summary_vi", "") or "").strip()
    angle = (article.get("editorial_angle", "") or "").strip()
    core = summary or article.get("title", "Bài viết này")
    confidence = grounding.get("confidence_label", "low")

    if confidence == "high":
        caution = "Nên ưu tiên theo dõi hoặc thử nhanh nếu đúng bài toán của team."
    elif confidence == "medium":
        caution = "Cần đọc thận trọng vì dữ liệu đầu vào vẫn còn một vài khoảng trống."
    else:
        caution = "Đây là tín hiệu yếu, nên chỉ theo dõi."

    if angle:
        return (
            f"Ý chính của tin này là: {core} Điểm đáng chú ý nhất là {angle.lower()}, "
            f"nhưng {caution.lower()}"
        )[:320]
    return (
        f"Ý chính của tin này là: {core} {caution} "
        "Chưa nên hành động khi thiếu thêm dữ liệu về giá trị thực tế."
    )[:320]


def compose_note_summary_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: tạo short note cho tất cả bài sẽ được lưu/gửi.

    Input ưu tiên:
      - analyzed_articles + low_score_articles
      - fallback scored_articles

    Output:
      - final_articles: list bài đã có note_summary_vi
    """
    analyzed = state.get("analyzed_articles", [])
    low_score = state.get("low_score_articles", [])
    final_articles = analyzed + low_score

    if not final_articles:
        final_articles = list(state.get("scored_articles", []))

    if not final_articles:
        logger.info("📭 Không có bài nào để compose short note.")
        return {"final_articles": []}

    total = len(final_articles)
    for i, article in enumerate(final_articles, 1):
        title = article.get("title", "N/A")
        logger.info("🧾 Note Summary [%d/%d]: %s", i, total, title[:60])

        grounding = build_article_grounding(article)
        article.update(grounding)

        long_analysis = article.get("content_page_md") or article.get("deep_analysis") or article.get("summary_vi", "")
        user_prompt = NOTE_SUMMARY_USER_TEMPLATE.format(
            title=title,
            primary_type=article.get("primary_type", "Unknown"),
            total_score=article.get("total_score", 0),
            editorial_angle=article.get("editorial_angle", "N/A"),
            summary_vi=article.get("summary_vi", ""),
            source_verified=article.get("source_verified", False),
            source_tier=article.get("source_tier", "unknown"),
            content_available=article.get("content_available", False),
            confidence_label=grounding.get("confidence_label", "low"),
            grounding_note=grounding.get("grounding_note", ""),
            fact_anchors=grounding.get("fact_anchors_text", "- Chưa có fact anchor mạnh."),
            reasonable_inferences=grounding.get("reasonable_inferences_text", "- Không có suy luận bổ sung."),
            unknowns=grounding.get("unknowns_text", "- Không có unknown lớn từ metadata."),
            analysis=long_analysis[:4500],
        )

        try:
            note = run_inference(
                NOTE_SUMMARY_SYSTEM,
                user_prompt,
                max_tokens=220,
                temperature=0.3,
            ).strip()
            if not note.startswith("Ý chính của tin này là:"):
                note = _fallback_note(article)
            article["note_summary_vi"] = note
        except Exception as e:
            logger.error("   ❌ Note summary failed: %s", e)
            article["note_summary_vi"] = _fallback_note(article)

    logger.info("✅ Short note hoàn tất: %d bài", len(final_articles))
    return {"final_articles": final_articles}
