"""
gather_news.py — LangGraph node: Thu thập tin tức AI/Tech.

Nguồn:
  1. RSS Feeds — timestamp chuẩn, filter 48h chính xác
  2. DuckDuckGo search — tin từ blog/site lớn + Việt Nam
  3. Telethon — Telegram channels (cộng đồng AI VN)
  4. Trafilatura + BeautifulSoup — trích xuất nội dung đầy đủ

LƯU Ý: Node này KHÔNG dedup — việc đó thuộc node deduplicate.
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone, timedelta
from typing import Any

from ddgs import DDGS
from trafilatura import fetch_url, extract
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# ── RSS Feeds — nguồn có timestamp chuẩn ────────────────────────────
RSS_FEEDS = [
    # Quốc tế
    "https://techcrunch.com/category/artificial-intelligence/feed/",
    "https://www.theverge.com/ai-artificial-intelligence/rss/index.xml",
    "https://feeds.arstechnica.com/arstechnica/technology-lab",
    "https://blog.google/technology/ai/rss/",
    # Việt Nam
    "https://vnexpress.net/rss/cong-nghe.rss",
    "https://genk.vn/rss/ai.rss",
]

# ── DuckDuckGo search queries ───────────────────────────────────────
SEARCH_QUERIES_EN = [
    "OpenAI latest news",
    "Anthropic Claude update",
    "Google DeepMind AI research",
    "Meta AI new model",
    "xAI Grok news",
    "HuggingFace open source AI",
    "AI breakthrough today",
]

SEARCH_QUERIES_VN = [
    "trí tuệ nhân tạo Việt Nam 2025",
    "AI startup Việt Nam mới nhất",
    "công nghệ AI Việt Nam tuần này",
]

# ── Domain blocklist — lọc trang rác/không liên quan ─────────────────
BLOCKED_DOMAINS = [
    "wikipedia.org", "tripadvisor.com", "amazon.com", "ebay.com",
    "linkedin.com", "facebook.com", "twitter.com", "instagram.com",
    "youtube.com", "reddit.com", "quora.com", "pinterest.com",
    "yelp.com", "booking.com",
]

# ── Telegram channels ───────────────────────────────────────────────
DEFAULT_CHANNELS = [
    "aivietnam", "MLVietnam", "binhdanhocai",
    "ai_mastering_vn", "nghienai",
]


# ── Bước 1: RSS Feeds ───────────────────────────────────────────────

def _fetch_rss(hours: int = 48) -> list[dict]:
    """
    Lấy bài từ RSS feeds, chỉ lấy bài trong N giờ qua.
    Dùng feedparser để parse timestamp chuẩn.

    Args:
        hours: Số giờ tính từ hiện tại (mặc định 48h)

    Returns:
        List bài viết {title, url, source, published, snippet}
    """
    try:
        import feedparser
    except ImportError:
        logger.warning("feedparser chưa cài — bỏ qua RSS.")
        return []

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    articles = []

    for feed_url in RSS_FEEDS:
        try:
            feed = feedparser.parse(feed_url)
            feed_title = feed.feed.get("title", feed_url)

            for entry in feed.entries[:10]:
                # Parse published date
                published = None
                if hasattr(entry, "published_parsed") and entry.published_parsed:
                    from time import mktime
                    published = datetime.fromtimestamp(
                        mktime(entry.published_parsed), tz=timezone.utc
                    )
                elif hasattr(entry, "updated_parsed") and entry.updated_parsed:
                    from time import mktime
                    published = datetime.fromtimestamp(
                        mktime(entry.updated_parsed), tz=timezone.utc
                    )

                # Chỉ lấy bài trong N giờ qua
                if published and published < cutoff:
                    continue

                url = entry.get("link", "")
                if not url:
                    continue

                # Trích xuất snippet từ summary/description
                snippet = ""
                if hasattr(entry, "summary"):
                    soup = BeautifulSoup(entry.summary, "html.parser")
                    snippet = soup.get_text(strip=True)[:500]

                articles.append({
                    "title": entry.get("title", ""),
                    "url": url,
                    "source": f"RSS: {feed_title}",
                    "snippet": snippet,
                    "published": published.isoformat() if published else "",
                    "fetched_at": datetime.now(timezone.utc).isoformat(),
                })

        except Exception as e:
            logger.warning("RSS fetch failed for %s: %s", feed_url[:50], e)

    return articles


# ── Bước 2: DuckDuckGo search ───────────────────────────────────────

def _search_ddg(query: str, max_results: int = 5) -> list[dict]:
    """Tìm kiếm DuckDuckGo và trả về kết quả, lọc domain rác."""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(
                query,
                max_results=max_results * 2,  # Lấy nhiều hơn để bù sau khi lọc
                timelimit="w",  # Chỉ lấy kết quả trong vòng 1 tuần
            ))
        # Lọc domain rác
        filtered = []
        for r in results:
            url = r.get("href") or r.get("link", "")
            if any(blocked in url for blocked in BLOCKED_DOMAINS):
                continue
            filtered.append(r)
        return filtered[:max_results]
    except Exception as e:
        logger.warning("DDG search failed for '%s': %s", query, e)
        return []


# ── Bước 3: Trích xuất nội dung đầy đủ ─────────────────────────────

def _extract_full_text(url: str) -> str:
    """Download và trích xuất nội dung chính từ URL."""
    try:
        downloaded = fetch_url(url)
        if downloaded:
            text = extract(downloaded, include_comments=False, include_tables=True)
            if text:
                return text[:5000]
            # Fallback: BeautifulSoup
            soup = BeautifulSoup(downloaded, "html.parser")
            for tag in soup(["script", "style", "nav", "footer", "header"]):
                tag.decompose()
            return soup.get_text(separator="\n", strip=True)[:5000]
    except Exception as e:
        logger.warning("Text extraction failed for %s: %s", url[:60], e)
    return ""


# ── Bước 4: Telegram channels ──────────────────────────────────────

async def _read_telegram_channels(
    channels: list[str],
    limit: int = 10,
) -> list[dict]:
    """
    Đọc messages gần nhất từ Telegram channels bằng Telethon.
    Cần TELETHON_API_ID và TELETHON_API_HASH trong .env.
    """
    api_id = os.getenv("TELETHON_API_ID")
    api_hash = os.getenv("TELETHON_API_HASH")
    session_name = os.getenv("TELETHON_SESSION_NAME", "digest_session")

    if not api_id or not api_hash:
        logger.info("Telethon credentials not set — skipping Telegram channels.")
        return []

    articles = []
    try:
        from telethon import TelegramClient

        client = TelegramClient(session_name, int(api_id), api_hash)
        await client.start()

        for channel_name in channels:
            try:
                channel = await client.get_entity(channel_name)
                async for message in client.iter_messages(channel, limit=limit):
                    if message.text and len(message.text) > 50:
                        url = f"https://t.me/{channel_name}/{message.id}"
                        articles.append({
                            "title": message.text[:120].replace("\n", " "),
                            "url": url,
                            "source": f"Telegram @{channel_name}",
                            "content": message.text,
                            "fetched_at": datetime.now(timezone.utc).isoformat(),
                        })
            except Exception as e:
                logger.warning("Failed to read channel @%s: %s", channel_name, e)

        await client.disconnect()
    except Exception as e:
        logger.warning("Telethon error: %s", e)

    return articles


# ── Node chính ──────────────────────────────────────────────────────

def gather_news_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: thu thập tin tức từ tất cả nguồn.

    Output: raw_articles (chưa dedup, chưa classify)
    """
    raw_articles: list[dict] = []

    # ── RSS Feeds (nguồn chính, có timestamp) ───────────────────────
    logger.info("📡 Fetching RSS feeds (48h qua) …")
    rss_articles = _fetch_rss(hours=48)
    logger.info("   RSS: %d bài", len(rss_articles))

    # Extract full text cho RSS articles
    for article in rss_articles:
        url = article.get("url", "")
        if url and not article.get("content"):
            article["content"] = _extract_full_text(url)
        raw_articles.append(article)

    # ── DuckDuckGo — English ────────────────────────────────────────
    logger.info("🔍 Searching English AI sources …")
    for query in SEARCH_QUERIES_EN:
        for result in _search_ddg(query, max_results=3):
            url = result.get("href") or result.get("link", "")
            if not url:
                continue
            full_text = _extract_full_text(url)
            raw_articles.append({
                "title": result.get("title", ""),
                "url": url,
                "source": "DuckDuckGo (EN)",
                "snippet": result.get("body", ""),
                "published": result.get("date", "") or result.get("published", ""),
                "content": full_text,
                "fetched_at": datetime.now(timezone.utc).isoformat(),
            })

    # ── DuckDuckGo — Vietnamese ─────────────────────────────────────
    logger.info("🔍 Searching Vietnamese tech sources …")
    for query in SEARCH_QUERIES_VN:
        for result in _search_ddg(query, max_results=3):
            url = result.get("href") or result.get("link", "")
            if not url:
                continue
            full_text = _extract_full_text(url)
            raw_articles.append({
                "title": result.get("title", ""),
                "url": url,
                "source": "DuckDuckGo (VN)",
                "snippet": result.get("body", ""),
                "published": result.get("date", "") or result.get("published", ""),
                "content": full_text,
                "fetched_at": datetime.now(timezone.utc).isoformat(),
            })

    # ── Telegram channels ───────────────────────────────────────────
    logger.info("📱 Reading Telegram channels …")
    channels_str = os.getenv("TELEGRAM_CHANNELS", "")
    channels = [c.strip() for c in channels_str.split(",") if c.strip()] or DEFAULT_CHANNELS

    try:
        tg_articles = asyncio.run(_read_telegram_channels(channels))
    except RuntimeError:
        tg_articles = []

    raw_articles.extend(tg_articles)

    logger.info("✅ Gathered %d raw articles total (RSS + DDG + Telegram)",
                len(raw_articles))
    return {"raw_articles": raw_articles}
