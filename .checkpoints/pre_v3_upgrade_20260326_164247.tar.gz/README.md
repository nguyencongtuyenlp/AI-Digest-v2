# 🤖 Daily Digest Agent

> Pure-local AI Agent chạy trên **Apple Silicon (M4 Pro)** — tự thu thập tin AI/Tech mỗi sáng, phân loại, lưu Notion, tóm tắt và gửi Telegram. **0₫ chi phí API inference.**

## ✨ Features

| Feature | Mô tả |
|---------|--------|
| 🔍 Multi-source gathering | DuckDuckGo (EN + VN) + Telegram channels |
| 🏷️ 6-type classification | Research · Product · Business · Policy · Society · Practical |
| 🧠 Local LLM inference | MLX trên Apple Silicon — Qwen3.5-35B-A3B-Instruct 4-bit |
| 📝 Notion archiving | Tự tạo page với formatted blocks |
| 📱 Telegram delivery | Gửi digest summary tới group/channel |
| 🔁 Deduplication | SQLite URL hashing — không lặp bài |
| 🛡️ Grounding guardrails | Tách `fact / inference / unknown` + fallback digest an toàn |
| ⏰ Auto-schedule | macOS launchd 8:00 sáng mỗi ngày |

## 🏗️ Architecture

```text
gather
  → normalize_source
  → deduplicate
  → classify_and_score
  → [top?] deep_analysis
  → recommend_idea
  → compose_note_summary
  → save_notion
  → summarize_vn
  → quality_gate
  → send_telegram
  → END
```

Toàn bộ pipeline dùng **LangGraph StateGraph** với typed state dict.

## 🚀 Cài đặt

### 1. Clone & tạo virtualenv

```bash
cd /Users/quangdang/Projects/daily-digest-agent
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Cấu hình `.env`

```bash
cp config/.env.example config/.env
# Mở config/.env và điền token thật
```

Bạn cần:
- **Notion**: Tạo [Internal Integration](https://www.notion.so/my-integrations), lấy token + share database
- **Telegram Bot**: Tạo bot qua [@BotFather](https://t.me/BotFather), lấy token + chat ID
- **Telethon** (optional): Đăng ký app tại [my.telegram.org](https://my.telegram.org) để đọc channels

### 3. Chạy thủ công

```bash
source .venv/bin/activate
python main.py
```

### 4. Cài launchd (auto 8:00 sáng)

```bash
cp launchd.plist ~/Library/LaunchAgents/com.quangdang.daily-digest-agent.plist
launchctl load ~/Library/LaunchAgents/com.quangdang.daily-digest-agent.plist
```

Kiểm tra:
```bash
launchctl list | grep digest
```

Gỡ:
```bash
launchctl unload ~/Library/LaunchAgents/com.quangdang.daily-digest-agent.plist
```

## 📁 Project Structure

```
daily-digest-agent/
├── main.py                  # Entry point
├── graph.py                 # LangGraph pipeline
├── editorial_guardrails.py  # Grounding + quality gate helpers
├── db.py                    # SQLite deduplication
├── requirements.txt
├── launchd.plist            # macOS scheduler
├── .gitignore
├── config/
│   ├── .env.example         # Environment template
│   └── prompt_daily_digest.md  # Master LLM prompt
├── nodes/
│   ├── __init__.py
│   ├── gather_news.py       # Node 1: Thu thập tin
│   ├── normalize_source.py  # Chuẩn hóa source/date/tier
│   ├── deduplicate.py       # Lọc trùng + recall memory
│   ├── classify_and_score.py # Editorial triage + scoring
│   ├── deep_analysis.py     # Phân tích sâu cho bài top
│   ├── recommend_idea.py    # Gợi ý hành động cho startup
│   ├── compose_note_summary.py # Executive note cho từng bài
│   ├── save_notion.py       # Lưu Notion + memory
│   ├── summarize_vn.py      # Soạn daily brief tiếng Việt
│   ├── quality_gate.py      # Sanity check trước Telegram
│   └── send_telegram.py     # Gửi Telegram
└── README.md
```

## 🐛 Debug

```bash
# Kiểm tra logs
cat digest.log
cat digest_error.log

# Chạy manually với debug
python main.py 2>&1 | tee debug_output.txt

# Kiểm tra database
python -c "from db import get_history; print(len(get_history()))"
```

## ⚙️ Tùy chỉnh

- **Thêm nguồn tin**: Sửa `SEARCH_QUERIES_EN` / `SEARCH_QUERIES_VN` trong `nodes/gather_news.py`
- **Đổi model**: Sửa `MLX_MODEL` trong `.env`
- **Đổi prompt**: Sửa `config/prompt_daily_digest.md`
- **Đổi giờ chạy**: Sửa `<integer>8</integer>` trong `launchd.plist`
