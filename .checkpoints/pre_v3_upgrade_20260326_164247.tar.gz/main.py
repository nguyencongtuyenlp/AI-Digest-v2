#!/usr/bin/env python3
"""
main.py — Entry point cho Daily Digest AI Agent (MVP2).

Load environment, compile LangGraph, chạy pipeline, log kết quả.
Model: Qwen2.5-72B-4bit trên Apple Silicon (MLX).
"""

from __future__ import annotations

import logging
import sys
import os
from datetime import datetime, timezone
from pathlib import Path

# Đảm bảo project root nằm trong sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dotenv import load_dotenv

# ── Load .env ───────────────────────────────────────────────────────────
env_path = PROJECT_ROOT / "config" / ".env"
if env_path.exists():
    load_dotenv(env_path)
else:
    load_dotenv(PROJECT_ROOT / ".env")

# ── Logging ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s │ %(levelname)-7s │ %(name)s │ %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("daily-digest")


def main() -> None:
    """Chạy toàn bộ pipeline Daily Digest Agent."""
    start = datetime.now(timezone.utc)
    logger.info("=" * 60)
    logger.info("🚀 Daily Digest AI Agent (MVP2)")
    logger.info("   Model: %s", os.getenv("MLX_MODEL", "N/A"))
    logger.info("   Time : %s", start.strftime("%Y-%m-%d %H:%M:%S UTC"))
    logger.info("=" * 60)

    from graph import build_graph

    app = build_graph()

    # Chạy graph với state rỗng ban đầu
    result = app.invoke({})

    # ── Log kết quả ─────────────────────────────────────────────────
    elapsed = (datetime.now(timezone.utc) - start).total_seconds()
    raw_count = len(result.get("raw_articles", []))
    new_count = len(result.get("new_articles", []))
    scored_count = len(result.get("scored_articles", []))
    top_count = len(result.get("top_articles", []))
    analyzed_count = len(result.get("analyzed_articles", []))
    notion_count = len(result.get("notion_pages", []))
    tg_sent = result.get("telegram_sent", False)

    logger.info("─" * 60)
    logger.info("📊 Pipeline completed in %.1f seconds (%.1f minutes)", elapsed, elapsed / 60)
    logger.info("   Raw articles gathered  : %d", raw_count)
    logger.info("   After dedup            : %d", new_count)
    logger.info("   Classified + scored    : %d", scored_count)
    logger.info("   Top (deep analyzed)    : %d", top_count)
    logger.info("   Deep analysis done     : %d", analyzed_count)
    logger.info("   Notion pages created   : %d", notion_count)
    logger.info("   Telegram sent          : %s", "✅" if tg_sent else "⏭️ skipped")
    logger.info("=" * 60)

    # ── Print summary ra stdout ─────────────────────────────────────
    summary = result.get("summary_vn", "")
    if summary:
        # Strip HTML tags cho console output
        import re
        clean = re.sub(r"<[^>]+>", "", summary)
        print("\n" + clean)


if __name__ == "__main__":
    main()
