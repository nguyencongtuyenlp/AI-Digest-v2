import unittest
from datetime import date

from editorial_guardrails import (
    build_article_grounding,
    build_safe_digest,
    validate_telegram_summary,
)
from nodes.normalize_source import normalize_source_node
from nodes.quality_gate import quality_gate_node
from nodes.save_notion import _project_fit_level, _resolve_property_map


class EditorialGuardrailsTest(unittest.TestCase):
    def test_build_article_grounding_high_confidence(self) -> None:
        article = {
            "title": "Reuters says model release expands enterprise usage",
            "source": "RSS: Reuters",
            "source_domain": "reuters.com",
            "published_at": "2026-03-26T01:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
            "total_score": 78,
            "community_reactions": "[News] Enterprises discuss rollout impact",
            "related_past": [{"title": "Older launch"}],
        }

        grounding = build_article_grounding(article)

        self.assertEqual(grounding["confidence_label"], "high")
        self.assertIn("Nguồn đang dùng để đọc tin", grounding["fact_anchors_text"])
        self.assertIn("diễn biến tiếp nối", grounding["reasonable_inferences_text"])
        self.assertEqual(grounding["unknowns"], [])

    def test_build_article_grounding_low_confidence(self) -> None:
        article = {
            "title": "Category page only",
            "source": "DuckDuckGo (EN)",
            "source_domain": "random-blog.example",
            "content_available": False,
            "source_verified": False,
            "source_tier": "c",
            "total_score": 12,
            "community_reactions": "",
        }

        grounding = build_article_grounding(article)

        self.assertEqual(grounding["confidence_label"], "low")
        self.assertGreaterEqual(len(grounding["unknowns"]), 2)
        self.assertIn("tier C", grounding["caution_flags_text"])

    def test_build_safe_digest_contains_header_and_link(self) -> None:
        articles = [{
            "title": "Anthropic adds enterprise controls",
            "note_summary_vi": "Ý chính của tin này là: doanh nghiệp có thêm công cụ quản trị để triển khai AI an toàn hơn.",
            "total_score": 72,
            "primary_type": "Product",
            "primary_emoji": "🚀",
            "source": "RSS: TechCrunch",
            "source_domain": "techcrunch.com",
            "published_at": "2026-03-26T02:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
            "community_reactions": "[News] buyers compare security posture",
        }]
        notion_pages = [{"title": "Anthropic adds enterprise controls", "url": "https://notion.so/example"}]

        digest = build_safe_digest(articles, notion_pages, today=date(2026, 3, 26))

        self.assertIn("<b>AI Daily Brief | 26/03</b>", digest)
        self.assertIn('<a href="https://notion.so/example">Đọc thêm</a>', digest)
        self.assertNotIn("[Đọc thêm](", digest)
        self.assertIn("🚀 Product |", digest)

    def test_validate_telegram_summary_catches_markdown_and_bad_links(self) -> None:
        articles = [{
            "title": "Strong source article",
            "note_summary_vi": "Ý chính của tin này là: đây là tin quan trọng cho team.",
            "total_score": 65,
            "source": "RSS: Reuters",
            "source_domain": "reuters.com",
            "published_at": "2026-03-26T03:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
        }]
        notion_pages = [{"title": "Strong source article", "url": "https://notion.so/good"}]
        summary = (
            "<b>AI Daily Brief | 26/03</b>\n\n"
            "[Đọc thêm](https://bad.example)\n\n"
            '<a href="https://bad.example">Đọc thêm</a>'
        )

        warnings = validate_telegram_summary(
            summary,
            articles,
            notion_pages,
            today=date(2026, 3, 26),
        )

        self.assertIn("markdown_links_present", warnings)
        self.assertIn("unknown_links_present", warnings)

    def test_quality_gate_falls_back_to_safe_digest(self) -> None:
        state = {
            "final_articles": [{
                "title": "Strong source article",
                "note_summary_vi": "Ý chính của tin này là: đây là tin quan trọng cho team.",
                "total_score": 65,
                "primary_type": "Business",
                "primary_emoji": "💼",
                "source": "RSS: Reuters",
                "source_domain": "reuters.com",
                "published_at": "2026-03-26T03:00:00+00:00",
                "content_available": True,
                "source_verified": True,
                "source_tier": "a",
            }],
            "notion_pages": [{"title": "Strong source article", "url": "https://notion.so/good"}],
            "summary_vn": "Bản tóm tắt lỗi format",
        }

        result = quality_gate_node(state)

        self.assertEqual(result["summary_mode"], "safe_fallback")
        self.assertIn("<b>AI Daily Brief |", result["summary_vn"])
        self.assertTrue(result["summary_warnings"])

    def test_resolve_property_map_supports_aliases(self) -> None:
        database_properties = {
            "Name": {"type": "title"},
            "URL": {"type": "url"},
            "Summary": {"type": "rich_text"},
            "Recommendation": {"type": "rich_text"},
            "Type": {"type": "select"},
            "Mức độ phù hợp": {"type": "select"},
            "Project fit": {"type": "select"},
            "Tags": {"type": "multi_select"},
            "Score": {"type": "number"},
        }

        property_map = _resolve_property_map(database_properties)

        self.assertEqual(property_map["url"], "URL")
        self.assertEqual(property_map["summary"], "Summary")
        self.assertEqual(property_map["recommend"], "Recommendation")
        self.assertEqual(property_map["project_fit"], "Project fit")
        self.assertEqual(property_map["tags"], "Tags")

    def test_project_fit_level_from_c3_score(self) -> None:
        self.assertEqual(_project_fit_level(28), "High")
        self.assertEqual(_project_fit_level(18), "Medium")
        self.assertEqual(_project_fit_level(8), "Low")

    def test_normalize_source_does_not_promote_fetched_at_to_published_at(self) -> None:
        state = {
            "raw_articles": [{
                "title": "Old article discovered today",
                "url": "https://example.com/old-news",
                "source": "DuckDuckGo (EN)",
                "fetched_at": "2026-03-26T09:00:00+00:00",
                "content": "A" * 300,
            }]
        }

        result = normalize_source_node(state)
        article = result["raw_articles"][0]

        self.assertEqual(article["published_at"], "")
        self.assertEqual(article["published_at_source"], "unknown")
        self.assertEqual(article["discovered_at"], "2026-03-26T09:00:00+00:00")
        self.assertTrue(article["freshness_unknown"])

    def test_normalize_source_marks_old_article_as_stale_candidate(self) -> None:
        state = {
            "raw_articles": [{
                "title": "Actually old article",
                "url": "https://example.com/old-news",
                "source": "RSS: Example",
                "published": "2026-03-01T09:00:00+00:00",
                "content": "A" * 300,
            }]
        }

        result = normalize_source_node(state)
        article = result["raw_articles"][0]

        self.assertEqual(article["published_at_source"], "source_metadata")
        self.assertTrue(article["is_stale_candidate"])


if __name__ == "__main__":
    unittest.main()
