import unittest
from datetime import date
from unittest.mock import patch

from editorial_guardrails import (
    build_article_grounding,
    build_safe_digest,
    build_safe_digest_messages,
    validate_telegram_messages,
    validate_telegram_summary,
)
from nodes.classify_and_score import (
    _annotate_event_clusters,
    _apply_freshness_penalty,
    _prepare_classify_candidates,
)
from nodes.delivery_judge import _deterministic_delivery_assessment
from nodes.normalize_source import normalize_source_node
from nodes.quality_gate import quality_gate_node
from nodes.save_notion import (
    _build_formatted_rich_text,
    _get_notion_parent_and_properties,
    _project_fit_level,
    _resolve_property_map,
)
from nodes.summarize_vn import summarize_vn_node


class EditorialGuardrailsTest(unittest.TestCase):
    def test_get_notion_parent_and_properties_supports_data_source_schema(self) -> None:
        class _FakeDatabases:
            def retrieve(self, database_id: str) -> dict:
                return {
                    "object": "database",
                    "id": database_id,
                    "data_sources": [{"id": "ds_123", "name": "News Database"}],
                }

        class _FakeDataSources:
            def retrieve(self, data_source_id: str) -> dict:
                self.last_id = data_source_id
                return {
                    "object": "data_source",
                    "id": data_source_id,
                    "properties": {
                        "Name": {"type": "title"},
                        "Link gốc": {"type": "url"},
                        "Summarize": {"type": "rich_text"},
                    },
                }

        class _FakeNotion:
            def __init__(self) -> None:
                self.databases = _FakeDatabases()
                self.data_sources = _FakeDataSources()

        parent, properties = _get_notion_parent_and_properties(_FakeNotion(), "db_123")

        self.assertEqual(parent, {"data_source_id": "ds_123"})
        self.assertIn("Link gốc", properties)
        self.assertEqual(properties["Summarize"]["type"], "rich_text")

    def test_build_formatted_rich_text_strips_markdown_headings(self) -> None:
        rich_text = _build_formatted_rich_text(
            "### 💡 Ý tưởng chính\nTạo hệ thống theo dõi cơ hội.\n\n### 📋 Bước thực hiện\n1. Thu thập nguồn\n2. Gửi thông báo"
        )

        plain = "".join(item["text"]["content"] for item in rich_text)

        self.assertIn("💡 Ý tưởng chính", plain)
        self.assertIn("📋 Bước thực hiện", plain)
        self.assertNotIn("###", plain)
        self.assertTrue(any(item.get("annotations", {}).get("bold") for item in rich_text))

    def test_build_article_grounding_high_confidence(self) -> None:
        article = {
            "title": "Reuters says model release expands enterprise usage",
            "source": "RSS: Reuters",
            "source_domain": "reuters.com",
            "published_at": "2026-03-26T01:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
            "total_score": 78,
            "community_reactions": "[News] Enterprises discuss rollout impact",
            "related_past": [{"title": "Older launch"}],
        }

        grounding = build_article_grounding(article)

        self.assertEqual(grounding["confidence_label"], "high")
        self.assertIn("Nguồn đang dùng để đọc tin", grounding["fact_anchors_text"])
        self.assertIn("diễn biến tiếp nối", grounding["reasonable_inferences_text"])
        self.assertEqual(grounding["unknowns"], [])

    def test_build_article_grounding_low_confidence(self) -> None:
        article = {
            "title": "Category page only",
            "source": "DuckDuckGo (EN)",
            "source_domain": "random-blog.example",
            "content_available": False,
            "source_verified": False,
            "source_tier": "c",
            "total_score": 12,
            "community_reactions": "",
        }

        grounding = build_article_grounding(article)

        self.assertEqual(grounding["confidence_label"], "low")
        self.assertGreaterEqual(len(grounding["unknowns"]), 2)
        self.assertIn("tier C", grounding["caution_flags_text"])

    def test_build_safe_digest_contains_header_and_link(self) -> None:
        articles = [{
            "title": "Anthropic adds enterprise controls",
            "note_summary_vi": "Ý chính của tin này là: doanh nghiệp có thêm công cụ quản trị để triển khai AI an toàn hơn.",
            "total_score": 72,
            "primary_type": "Product",
            "primary_emoji": "🚀",
            "source": "RSS: TechCrunch",
            "source_domain": "techcrunch.com",
            "published_at": "2026-03-26T02:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
            "community_reactions": "[News] buyers compare security posture",
        }]
        notion_pages = [{"title": "Anthropic adds enterprise controls", "url": "https://notion.so/example"}]

        digest = build_safe_digest(articles, notion_pages, today=date(2026, 3, 26))

        self.assertIn("AI Daily Brief | 26/03", digest)
        self.assertIn('<a href="https://notion.so/example">Đọc thêm</a>', digest)
        self.assertNotIn("[Đọc thêm](", digest)
        self.assertIn("🚀 Product | AI Daily Brief | 26/03", digest)
        self.assertNotIn("Sáng nay có", digest)
        self.assertNotIn("Điểm 72/100", digest)
        self.assertNotIn("Độ chắc", digest)

    def test_build_safe_digest_messages_marks_repeat_history_items(self) -> None:
        history_articles = [{
            "title": "Gemini adds workspace import",
            "url": "https://example.com/gemini-import",
            "primary_type": "Product",
            "summary": "Ý chính của tin này là: Google giúp người dùng chuyển dữ liệu chatbot sang Gemini.",
            "source": "RSS: Example",
            "relevance_score": 78,
            "created_at": "2026-03-26T01:00:00+00:00",
        }]

        messages = build_safe_digest_messages([], [], history_articles=history_articles, today=date(2026, 3, 26))

        self.assertEqual(len(messages), 6)
        product_message = next(message for message in messages if "🚀 Product" in message)
        self.assertIn("brief 8h trước đó", product_message)
        self.assertIn("Gemini adds workspace import", product_message)

    def test_validate_telegram_summary_catches_markdown_and_bad_links(self) -> None:
        articles = [{
            "title": "Strong source article",
            "note_summary_vi": "Ý chính của tin này là: đây là tin quan trọng cho team.",
            "total_score": 65,
            "source": "RSS: Reuters",
            "source_domain": "reuters.com",
            "published_at": "2026-03-26T03:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
        }]
        notion_pages = [{"title": "Strong source article", "url": "https://notion.so/good"}]
        summary = (
            "<b>AI Daily Brief | 26/03</b>\n\n"
            "[Đọc thêm](https://bad.example)\n\n"
            '<a href="https://bad.example">Đọc thêm</a>'
        )

        warnings = validate_telegram_summary(
            summary,
            articles,
            notion_pages,
            today=date(2026, 3, 26),
        )

        self.assertIn("markdown_links_present", warnings)
        self.assertIn("unknown_links_present", warnings)

    def test_validate_telegram_messages_accepts_six_type_messages(self) -> None:
        articles = [{
            "title": "Strong source article",
            "note_summary_vi": "Ý chính của tin này là: đây là tin quan trọng cho team.",
            "total_score": 65,
            "primary_type": "Business",
            "source": "RSS: Reuters",
            "source_domain": "reuters.com",
            "url": "https://example.com/strong-source",
            "published_at": "2026-03-26T03:00:00+00:00",
            "content_available": True,
            "source_verified": True,
            "source_tier": "a",
        }]
        messages = build_safe_digest_messages(articles, [], today=date(2026, 3, 26))

        warnings = validate_telegram_messages(messages, articles, [], today=date(2026, 3, 26))

        self.assertEqual(warnings, [])

    def test_quality_gate_falls_back_to_safe_digest(self) -> None:
        state = {
            "final_articles": [{
                "title": "Strong source article",
                "note_summary_vi": "Ý chính của tin này là: đây là tin quan trọng cho team.",
                "total_score": 65,
                "primary_type": "Business",
                "primary_emoji": "💼",
                "source": "RSS: Reuters",
                "source_domain": "reuters.com",
                "published_at": "2026-03-26T03:00:00+00:00",
                "content_available": True,
                "source_verified": True,
                "source_tier": "a",
            }],
            "notion_pages": [{"title": "Strong source article", "url": "https://notion.so/good"}],
            "summary_vn": "Bản tóm tắt lỗi format",
        }

        result = quality_gate_node(state)

        self.assertEqual(result["summary_mode"], "safe_fallback")
        self.assertIn("AI Daily Brief |", result["summary_vn"])
        self.assertEqual(len(result["telegram_messages"]), 6)
        self.assertTrue(result["summary_warnings"])

    def test_resolve_property_map_supports_aliases(self) -> None:
        database_properties = {
            "Name": {"type": "title"},
            "URL": {"type": "url"},
            "Summary": {"type": "rich_text"},
            "Recommendation": {"type": "rich_text"},
            "Type": {"type": "select"},
            "Mức độ phù hợp": {"type": "select"},
            "Project fit": {"type": "select"},
            "Tags": {"type": "multi_select"},
            "Score": {"type": "number"},
        }

        property_map = _resolve_property_map(database_properties)

        self.assertEqual(property_map["url"], "URL")
        self.assertEqual(property_map["summary"], "Summary")
        self.assertEqual(property_map["recommend"], "Recommendation")
        self.assertEqual(property_map["project_fit"], "Project fit")
        self.assertEqual(property_map["tags"], "Tags")

    def test_project_fit_level_from_c3_score(self) -> None:
        self.assertEqual(_project_fit_level(28), "High")
        self.assertEqual(_project_fit_level(18), "Medium")
        self.assertEqual(_project_fit_level(8), "Low")

    def test_normalize_source_does_not_promote_fetched_at_to_published_at(self) -> None:
        state = {
            "raw_articles": [{
                "title": "Old article discovered today",
                "url": "https://example.com/old-news",
                "source": "DuckDuckGo (EN)",
                "fetched_at": "2026-03-26T09:00:00+00:00",
                "content": "A" * 300,
            }]
        }

        result = normalize_source_node(state)
        article = result["raw_articles"][0]

        self.assertEqual(article["published_at"], "")
        self.assertEqual(article["published_at_source"], "unknown")
        self.assertEqual(article["discovered_at"], "2026-03-26T09:00:00+00:00")
        self.assertTrue(article["freshness_unknown"])

    def test_normalize_source_marks_old_article_as_stale_candidate(self) -> None:
        state = {
            "raw_articles": [{
                "title": "Actually old article",
                "url": "https://example.com/old-news",
                "source": "RSS: Example",
                "published": "2026-03-01T09:00:00+00:00",
                "content": "A" * 300,
            }]
        }

        result = normalize_source_node(state)
        article = result["raw_articles"][0]

        self.assertEqual(article["published_at_source"], "source_metadata")
        self.assertTrue(article["is_stale_candidate"])

    def test_normalize_source_can_infer_date_from_url(self) -> None:
        state = {
            "raw_articles": [{
                "title": "Cafef style article with encoded date",
                "url": "https://cafef.vn/fpt-cung-nvidia-tro-luc-ai-startup-188250520171429754.chn",
                "source": "DuckDuckGo (VN)",
                "content": "A" * 300,
            }]
        }

        result = normalize_source_node(state)
        article = result["raw_articles"][0]

        self.assertEqual(article["published_at_source"], "url_pattern")
        self.assertTrue(article["published_at"].startswith("2025-05-20"))
        self.assertTrue(article["is_old_news"])

    def test_freshness_penalty_reduces_old_article_score(self) -> None:
        article = {
            "title": "Old but flashy article",
            "total_score": 72,
            "analysis_tier": "deep",
            "source_tier": "a",
            "freshness_unknown": False,
            "is_stale_candidate": True,
            "content_available": True,
        }

        _apply_freshness_penalty(article, min_score=60)

        self.assertLess(article["total_score"], 72)
        self.assertEqual(article["freshness_status"], "stale_candidate")
        self.assertIn(article["analysis_tier"], {"basic", "skip"})

    def test_event_clustering_marks_primary_article(self) -> None:
        articles = [
            {
                "title": "OpenAI launches new coding agent for enterprise teams",
                "total_score": 70,
                "source_tier": "a",
                "content_available": True,
                "freshness_unknown": False,
            },
            {
                "title": "OpenAI launches enterprise coding agent for software teams",
                "total_score": 62,
                "source_tier": "b",
                "content_available": True,
                "freshness_unknown": False,
            },
            {
                "title": "Vietnam AI startup raises seed round",
                "total_score": 55,
                "source_tier": "b",
                "content_available": True,
                "freshness_unknown": False,
            },
        ]

        primaries = _annotate_event_clusters(articles, min_score=60)

        self.assertEqual(len(primaries), 2)
        clustered = [article for article in articles if article.get("event_cluster_size") == 2]
        self.assertEqual(len(clustered), 2)
        self.assertEqual(sum(1 for article in clustered if article.get("event_is_primary")), 1)

    def test_prefilter_limits_candidates_before_llm_classify(self) -> None:
        articles = [
            {
                "title": "OpenAI ships new enterprise agent controls",
                "source_tier": "a",
                "freshness_bucket": "fresh",
                "content_available": True,
                "source_verified": True,
                "is_old_news": False,
                "is_stale_candidate": False,
            },
            {
                "title": "Anthropic launches workflow automation features",
                "source_tier": "a",
                "freshness_bucket": "recent",
                "content_available": True,
                "source_verified": True,
                "is_old_news": False,
                "is_stale_candidate": False,
            },
            {
                "title": "Celebrity smartphone camera roundup",
                "source_tier": "c",
                "freshness_bucket": "fresh",
                "content_available": False,
                "source_verified": False,
                "is_old_news": False,
                "is_stale_candidate": False,
            },
        ]

        selected, held_out = _prepare_classify_candidates(articles, max_candidates=2)

        self.assertEqual(len(selected), 2)
        self.assertEqual(len(held_out), 1)
        self.assertIn("OpenAI ships", selected[0]["title"])
        self.assertIn("Celebrity smartphone", held_out[0]["title"])

    def test_delivery_judge_skips_duplicate_event_article(self) -> None:
        article = {
            "title": "Duplicate article",
            "total_score": 68,
            "source_tier": "a",
            "confidence_label": "high",
            "content_available": True,
            "freshness_unknown": False,
            "is_stale_candidate": False,
            "event_is_primary": False,
            "event_cluster_size": 2,
        }

        result = _deterministic_delivery_assessment(article)

        self.assertEqual(result["decision"], "skip")

    def test_delivery_judge_skips_old_news_even_if_not_stale_candidate(self) -> None:
        article = {
            "title": "Two-week old article",
            "total_score": 74,
            "source_tier": "b",
            "confidence_label": "medium",
            "content_available": True,
            "freshness_unknown": False,
            "freshness_bucket": "aging",
            "is_old_news": True,
            "is_stale_candidate": False,
            "event_is_primary": True,
            "event_cluster_size": 1,
        }

        result = _deterministic_delivery_assessment(article)

        self.assertEqual(result["decision"], "skip")

    @patch("nodes.summarize_vn.get_history", return_value=[])
    def test_summarize_vn_does_not_bypass_empty_delivery_judge(self, _mock_get_history) -> None:
        state = {
            "final_articles": [{
                "title": "Should not leak through",
                "note_summary_vi": "Ý chính của tin này là: đây là tin yếu.",
                "total_score": 80,
                "primary_type": "Business",
                "primary_emoji": "💼",
                "source": "RSS: Example",
                "source_domain": "example.com",
                "published_at": "2026-03-26T03:00:00+00:00",
                "content_available": True,
                "source_verified": True,
                "source_tier": "a",
            }],
            "telegram_candidates": [],
            "notion_pages": [],
            "scored_articles": [{
                "title": "Fallback article",
                "note_summary_vi": "Ý chính của tin này là: không nên xuất hiện.",
                "total_score": 90,
            }],
        }

        result = summarize_vn_node(state)

        self.assertEqual(len(result["telegram_messages"]), 6)
        self.assertNotIn("Fallback article", result["summary_vn"])
        self.assertIn("Should not leak through", result["summary_vn"])

    def test_delivery_judge_skips_unknown_weak_source(self) -> None:
        article = {
            "title": "Weak source article",
            "total_score": 59,
            "source_tier": "c",
            "confidence_label": "medium",
            "content_available": True,
            "freshness_unknown": True,
            "is_stale_candidate": False,
            "event_is_primary": True,
            "event_cluster_size": 1,
        }

        result = _deterministic_delivery_assessment(article)

        self.assertEqual(result["decision"], "skip")


if __name__ == "__main__":
    unittest.main()
