"""
summarize_vn.py — LangGraph node: Tổng hợp daily digest tiếng Việt cho Telegram.

Node này không tự tóm tắt từng bài nữa. Thay vào đó, nó nhận `note_summary_vi`
đã được nén riêng ở node trước và ghép thành một daily digest tự nhiên hơn.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import get_history
from editorial_guardrails import build_safe_digest, build_safe_digest_messages

logger = logging.getLogger(__name__)


def summarize_vn_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: dựng 6 Telegram messages cố định theo type.
    Nếu không có tin mới đủ dùng, nhắc lại các tin gần nhất đã báo cáo trước đó.
    """
    final_articles = state.get("final_articles", [])
    notion_pages = state.get("notion_pages", [])
    history_articles = get_history(days=3, limit=80)

    telegram_messages = build_safe_digest_messages(
        final_articles,
        notion_pages,
        history_articles=history_articles,
        per_type=3,
    )

    if not telegram_messages:
        safe_summary = build_safe_digest(final_articles, notion_pages, history_articles=history_articles)
        logger.info("✅ Không dựng được sections, dùng safe digest deterministic.")
        return {
            "summary_vn": safe_summary,
            "telegram_messages": [safe_summary],
            "summary_mode": "deterministic_fallback",
        }

    summary = "\n\n".join(telegram_messages)
    logger.info("✅ Built %d Telegram type messages.", len(telegram_messages))
    return {
        "summary_vn": summary,
        "telegram_messages": telegram_messages,
        "summary_mode": "deterministic_sections",
    }
