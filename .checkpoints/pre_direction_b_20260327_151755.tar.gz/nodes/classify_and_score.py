"""
classify_and_score.py — LangGraph node: Phân loại + chấm relevance theo vai "editorial triage".

Mục tiêu là để Qwen local đóng vai tương tự một bộ lọc kiểu Claude:
  1. Classify: gán 1 trong 6 Primary Types
  2. Score: chấm 1-100 dựa trên 3 tiêu chí
  3. Decision: quyết định bài nào cần phân tích sâu, bài nào chỉ lưu cơ bản

6 Primary Types:
  🔬 Research    — Nghiên cứu mới, paper, benchmark, thuật toán mới, bài báo công nghệ tốt cho tối ưu AI trên phần cứng nhỏ mà có sức mạnh lớn,...
  🚀 Product     — Ra mắt sản phẩm, tính năng, API mới, mô hình AI mới, các sản phẩm AI mới, các sản phẩm AI thiết bị biên, ...
  💼 Business    — M&A, funding, chiến lược, nhân sự, doanh thu, lợi nhuận, ...
  ⚖️ Policy      — Luật, quy định, đạo đức AI, chính sách,...
  🌍 Society     — Tác động xã hội, văn hóa, giáo dục, ứng dụng AI vào giáo dục, vào xã hội, vào y tế, vào kinh doanh, ...
  🛠️ Practical   — Hướng dẫn, tips, tools, tutorials, ứng dụng AI vào đời sống,...

3 Tiêu chí chấm điểm (mỗi tiêu chí 0-33 điểm, tổng max 100):
  C1. Chất lượng tin: Relevance, Timeliness, Impact, Source credibility, những người đầu ngành nói gì về nó,...
  C2. Phù hợp startup AI: Ứng dụng được vào SME/startup Việt Nam không? Có thể học hỏi được gì từ nó, có thể làm gì với nó, có thể bán cho ai, có thể hợp tác với ai, ...
  C3. Phù hợp dự án hiện tại: AI Agent, Revenue automation, Enterprise mgmt, AI Product general, ...

Output ghi vào state:
  scored_articles: tất cả bài đã classify + score
  top_articles: bài có score >= MIN_DEEP_ANALYSIS_SCORE
  low_score_articles: bài có score thấp
"""

from __future__ import annotations

import logging
import os
import re
import sys
import unicodedata
from pathlib import Path
from typing import Any

# Đảm bảo project root nằm trong sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from mlx_runner import run_json_inference

logger = logging.getLogger(__name__)


STRATEGIC_KEYWORDS = (
    "open-source",
    "open source",
    "dominance",
    "partnership",
    "partners with",
    "market lead",
    "threatens",
    "race",
    "ecosystem",
    "infrastructure",
    "robotics",
    "advisory body",
    "warns",
    "competition",
)

BUSINESS_KEYWORDS = (
    "startup",
    "funding",
    "partnership",
    "partners with",
    "market",
    "competition",
    "competitive",
    "lead",
    "dominance",
    "robotics",
)

SOCIETY_KEYWORDS = (
    "ecosystem",
    "student",
    "students",
    "education",
    "community",
)

AI_SIGNAL_KEYWORDS = (
    "ai",
    "agent",
    "model",
    "llm",
    "openai",
    "anthropic",
    "claude",
    "gpt",
    "deepmind",
    "gemini",
    "meta",
    "xai",
    "grok",
    "hugging face",
    "nvidia",
    "robot",
    "robotics",
    "chip",
    "inference",
    "training",
    "benchmark",
    "research",
    "startup",
    "funding",
    "acquisition",
    "partnership",
    "regulation",
    "policy",
)

OFF_SCOPE_KEYWORDS = (
    "smartphone",
    "camera",
    "melania trump",
    "meteor",
    "mảnh thiên thạch",
    "thien thach",
    "dịch vụ công",
    "dich vu cong",
    "weather",
    "football",
    "showbiz",
)

TITLE_STOPWORDS = {
    "the", "a", "an", "and", "or", "for", "with", "into", "from", "that", "this",
    "news", "today", "latest", "update", "updates", "report", "reports", "says",
    "new", "launches", "launch", "announces", "introduces", "about", "after",
    "tai", "cua", "cho", "voi", "trong", "mot", "nhung", "nhat", "moi", "bao",
    "ve", "sau", "tren", "khi", "nguoi", "viet", "nam", "tri", "tue", "nhan", "tao",
}

# ── Prompt Master cho classify + score ───────────────────────────────
CLASSIFY_SCORE_SYSTEM = """Bạn là Editorial Triage Lead cho một sản phẩm AI Daily Digest trả phí.
Nhiệm vụ: đọc nhanh từng nguồn tin AI/Tech, chấm điểm relevance như một biên tập viên khó tính,
và quyết định bài nào đáng được đưa vào phân tích sâu.

## 6 Primary Types (CHỌN ĐÚNG 1):
- 🔬 Research: Nghiên cứu mới, paper khoa học, benchmark, thuật toán mới
- 🚀 Product: Ra mắt sản phẩm, tính năng mới, API, platform update
- 💼 Business: M&A, funding, chiến lược kinh doanh, tuyển dụng, cạnh tranh
- ⚖️ Policy: Luật pháp, quy định, đạo đức AI, governance
- 🌍 Society: Tác động xã hội, văn hóa, giáo dục, việc làm
- 🛠️ Practical: Hướng dẫn, tips, tools, tutorials, best practices

## 3 Tiêu chí chấm điểm (mỗi tiêu chí 0-33, tổng max 100):

### C1: Chất lượng tin tức (0-33)
- Nguồn đáng tin cậy? (Reuters, TechCrunch, MIT = cao; blog random = thấp)
- Tin mới (24-48h qua) hay cũ?
- Tác động lớn đến ngành AI?
- Có dữ liệu/dẫn chứng cụ thể?
- Tin chiến lược ở nguồn mạnh về cạnh tranh AI, open-source, partnership, đầu tư hạ tầng, hay cảnh báo từ cơ quan lớn phải được xem là impact cao, kể cả khi nội dung đầu vào ngắn.

### C2: Phù hợp startup AI Việt Nam (0-33)
- Startup AI tại Việt Nam có thể ứng dụng/học hỏi?
- Liên quan đến thị trường Đông Nam Á?
- Có cơ hội kinh doanh?

### C3: Phù hợp dự án hiện tại (0-34)
Công ty đang phát triển 4 MVP:
1. AI News Digest (thu thập, phân tích, tổng hợp tin tức AI tự động)
2. AI Revenue Calculator (tính toán doanh thu, truy cập mọi nơi trong công ty)
3. AI Enterprise Management (quản lý toàn bộ công ty)
4. AI Product general (hướng phát triển sản phẩm AI)
- Tin này có giúp cải thiện sản phẩm nào ở trên không?
- Có công nghệ/ý tưởng mới áp dụng được?

## Rules bổ sung:
- Ưu tiên phân loại `Business` nếu bài nói về cạnh tranh thị trường, open-source race, partnership, strategic move, market lead, ecosystem control, hoặc tác động đến vị thế công ty/quốc gia trong ngành.
- Chỉ chọn `Policy` nếu trọng tâm chính là luật, quy định, compliance, governance, an toàn, hoặc can thiệp của cơ quan quản lý.
- Cấp độ phù hợp (relevance_level): High (Tổng C1+C2+C3 >= 70), Medium (40-69), Low (< 40)
- Mức xử lý (analysis_tier):
  - deep: bài đủ mạnh để đầu tư research/thinking sâu
  - basic: nên lưu và đưa vào digest, nhưng không cần research dài
  - skip: tín hiệu yếu, ít giá trị với sản phẩm kinh doanh
- Nếu nguồn mạnh (đặc biệt Reuters/CNBC/Bloomberg/TechCrunch) và chủ đề mang tính chiến lược cấp ngành, mặc định nghiêng về `deep` trừ khi bài quá mỏng hoặc không liên quan AI.
- editorial_angle: 1 câu nói rõ "điểm đáng quan tâm nhất" của bài này dưới góc nhìn người vận hành startup AI
- Tags: Chọn 3-5 từ khóa tiếng Anh miêu tả đúng nhất, viết thường (lowercase)
- KHÔNG TỰ TÍNH TỔNG ĐIỂM trong JSON (bộ phận Python sẽ lo việc tính tổng).
- Không hype. Không dùng ngôn ngữ quảng cáo. Nếu thiếu dữ liệu, nói rõ là thiếu dữ liệu.
- Nếu Content_available=false (thiếu nội dung) hoặc Published_at trống: hạ điểm C1, tránh kết luận mạnh.

## Output: JSON (KHÔNG markdown, KHÔNG giải thích thêm)
{
  "primary_type": "Research|Product|Business|Policy|Society|Practical",
  "primary_emoji": "🔬|🚀|💼|⚖️|🌍|🛠️",
  "c1_score": 0-33,
  "c1_reason": "Giải thích ngắn gọn (1 câu)",
  "c2_score": 0-33,
  "c2_reason": "Giải thích ngắn gọn (1 câu)",
  "c3_score": 0-34,
  "c3_reason": "Giải thích ngắn gọn (1 câu)",
  "summary_vi": "Tóm tắt 2-3 câu bằng tiếng Việt",
  "editorial_angle": "1 câu về điểm đáng quan tâm nhất",
  "analysis_tier": "deep|basic|skip",
  "tags": ["tag1", "tag2", "tag3"],
  "relevance_level": "High|Medium|Low"
}"""

CLASSIFY_SCORE_USER_TEMPLATE = """Phân loại và chấm điểm bài viết sau:

Tiêu đề: {title}
URL: {url}
Nguồn: {source}
Domain: {source_domain}
Published_at (UTC ISO): {published_at}
Published_at_source: {published_at_source}
Discovered_at: {discovered_at}
Age_hours: {age_hours}
Freshness_unknown: {freshness_unknown}
Is_stale_candidate: {is_stale_candidate}
Source_verified (heuristic): {source_verified}
Content_available: {content_available}
Nội dung: {content}

{related_context}

Trả về JSON theo format yêu cầu."""


def _prefilter_primary_type(title: str) -> tuple[str, str]:
    lowered = str(title or "").lower()
    if any(token in lowered for token in ("law", "regulation", "policy", "governance", "luật", "pháp lý", "quan ly")):
        return "Policy", "⚖️"
    if any(token in lowered for token in ("paper", "research", "benchmark", "study", "nghiên cứu")):
        return "Research", "🔬"
    if any(token in lowered for token in BUSINESS_KEYWORDS):
        return "Business", "💼"
    if any(token in lowered for token in ("launch", "release", "api", "model", "feature", "ra mắt", "công bố")):
        return "Product", "🚀"
    if any(token in lowered for token in ("tutorial", "guide", "tool", "workflow", "tips")):
        return "Practical", "🛠️"
    return "Society", "🌍"


def _prefilter_score(article: dict[str, Any]) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    title = str(article.get("title", "") or "")
    lowered_title = title.lower()
    source_tier = str(article.get("source_tier", "unknown")).lower()
    freshness_bucket = str(article.get("freshness_bucket", "unknown")).lower()

    tier_bonus = {"a": 10, "b": 7, "c": 3, "unknown": 1}.get(source_tier, 0)
    score += tier_bonus
    reasons.append(f"tier:{source_tier}+{tier_bonus}")

    freshness_bonus = {
        "breaking": 10,
        "fresh": 8,
        "recent": 5,
        "aging": -3,
        "stale": -8,
        "unknown": 0,
    }.get(freshness_bucket, 0)
    score += freshness_bonus
    if freshness_bonus:
        reasons.append(f"freshness:{freshness_bucket}{freshness_bonus:+d}")

    if article.get("content_available"):
        score += 4
        reasons.append("content+4")
    else:
        score -= 3
        reasons.append("thin_content-3")

    if article.get("source_verified"):
        score += 3
        reasons.append("verified+3")

    if article.get("related_past"):
        score += 1
        reasons.append("related_history+1")

    ai_hits = sum(1 for keyword in AI_SIGNAL_KEYWORDS if keyword in lowered_title)
    if ai_hits:
        ai_bonus = min(8, ai_hits * 2)
        score += ai_bonus
        reasons.append(f"ai_hits+{ai_bonus}")

    offscope_hits = [keyword for keyword in OFF_SCOPE_KEYWORDS if keyword in lowered_title]
    if offscope_hits:
        penalty = min(10, len(offscope_hits) * 4)
        score -= penalty
        reasons.append(f"offscope-{penalty}")

    if article.get("is_old_news"):
        score -= 8
        reasons.append("old_news-8")

    if article.get("is_stale_candidate"):
        score -= 12
        reasons.append("stale-12")

    return score, reasons


def _prefilter_sort_key(article: dict[str, Any]) -> tuple[int, int, int, int]:
    freshness_rank = {
        "breaking": 5,
        "fresh": 4,
        "recent": 3,
        "unknown": 2,
        "aging": 1,
        "stale": 0,
    }
    tier_rank = {"a": 3, "b": 2, "c": 1, "unknown": 0}
    return (
        int(article.get("prefilter_score", 0) or 0),
        freshness_rank.get(str(article.get("freshness_bucket", "unknown")).lower(), 0),
        tier_rank.get(str(article.get("source_tier", "unknown")).lower(), 0),
        1 if article.get("content_available") else 0,
    )


def _prepare_classify_candidates(articles: list[dict[str, Any]], max_candidates: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    ranked: list[dict[str, Any]] = []
    for article in articles:
        prefilter_score, reasons = _prefilter_score(article)
        article["prefilter_score"] = prefilter_score
        article["prefilter_reasons"] = reasons
        ranked.append(article)

    ranked.sort(key=_prefilter_sort_key, reverse=True)
    return ranked[:max_candidates], ranked[max_candidates:]


def _held_out_article_fallback(article: dict[str, Any]) -> None:
    title = str(article.get("title", "") or "Bài viết")
    prefilter_score = int(article.get("prefilter_score", 0) or 0)
    total_score = max(0, min(36, prefilter_score + 12))
    primary_type, primary_emoji = _prefilter_primary_type(title)

    article.update({
        "primary_type": primary_type,
        "primary_emoji": primary_emoji,
        "c1_score": max(0, min(16, total_score // 2)),
        "c1_reason": "Bài này bị giữ ở lớp prefilter để tiết kiệm tài nguyên cho 32B, nên mới chỉ có đánh giá sơ bộ.",
        "c2_score": max(0, min(10, total_score // 4)),
        "c2_reason": "Chưa đủ tín hiệu ban đầu để ưu tiên chấm sâu ở vòng đầu.",
        "c3_score": max(0, min(10, total_score // 4)),
        "c3_reason": "Nếu chủ đề này lặp lại ở nguồn mạnh hơn thì nên kéo lên xét lại.",
        "total_score": total_score,
        "summary_vi": (
            "Bài này hiện được giữ ở lớp sàng lọc sơ bộ để ưu tiên tài nguyên cho nhóm tin mới và mạnh hơn."
        ),
        "editorial_angle": "Tạm thời chỉ nên theo dõi, chưa đáng chiếm slot suy luận 32B ở vòng đầu.",
        "analysis_tier": "basic" if total_score >= 24 else "skip",
        "tags": list(_title_tokens(title))[:4],
    })
    _recompute_relevance_level(article)


def _build_related_context(article: dict) -> str:
    """
    Nếu bài viết có related_past (từ deduplicate), thêm vào context
    để model biết "đã từng đưa tin chủ đề này".
    """
    related = article.get("related_past", [])
    if not related:
        return ""

    lines = ["Bài viết LIÊN QUAN ĐÃ ĐĂNG trước đó:"]
    for r in related[:3]:
        lines.append(f"  - [{r.get('primary_type', '?')}] {r.get('title', 'N/A')}")
    lines.append("Hãy xem xét: bài mới có điểm gì khác so với bài cũ?")
    return "\n".join(lines)


def _apply_strategic_boost(article: dict[str, Any], min_score: int) -> None:
    """
    Heuristic nhẹ để tránh under-score các tin chiến lược nguồn mạnh.
    Không thay thế model; chỉ kéo lên khi hội đủ tín hiệu rõ ràng.
    """
    domain = str(article.get("source_domain", "")).lower()
    title = str(article.get("title", "")).lower()
    source_tier = str(article.get("source_tier", "")).lower()
    content_available = bool(article.get("content_available", False))

    strategic = any(keyword in title for keyword in STRATEGIC_KEYWORDS)
    strong_source = source_tier == "a" or domain in {"reuters.com", "cnbc.com", "bloomberg.com", "techcrunch.com"}

    if not (strategic and strong_source):
        return

    current_type = str(article.get("primary_type", ""))
    score = int(article.get("total_score", 0) or 0)

    # Kéo `Policy` về `Business` nếu bản chất là cuộc đua/chien luoc thi truong.
    if current_type == "Policy":
        article["primary_type"] = "Business"
        article["primary_emoji"] = "💼"

    # Nguồn mạnh + tín hiệu chiến lược + score đã khá gần ngưỡng thì đẩy lên deep.
    if score >= max(40, min_score - 20):
        article["analysis_tier"] = "deep"
        article["relevance_level"] = "High" if score >= 55 else article.get("relevance_level", "Medium")

        # Nếu content đầy đủ, boost thêm chút để tăng cơ hội vào top list.
        if content_available and score < min_score:
            article["total_score"] = min(min_score, score + 8)


def _normalize_key(text: str) -> str:
    ascii_text = unicodedata.normalize("NFKD", str(text or "")).encode("ascii", "ignore").decode("ascii")
    return ascii_text.lower()


def _title_tokens(title: str) -> set[str]:
    normalized = _normalize_key(title)
    tokens = {
        token for token in re.findall(r"[a-z0-9]+", normalized)
        if len(token) >= 3 and token not in TITLE_STOPWORDS
    }
    return tokens


def _recompute_relevance_level(article: dict[str, Any]) -> None:
    score = int(article.get("total_score", 0) or 0)
    if score >= 70:
        article["relevance_level"] = "High"
    elif score >= 40:
        article["relevance_level"] = "Medium"
    else:
        article["relevance_level"] = "Low"


def _apply_freshness_penalty(article: dict[str, Any], min_score: int) -> None:
    """
    Phạt deterministic cho bài stale hoặc không rõ freshness để tránh old-news leakage.
    """
    score = int(article.get("total_score", 0) or 0)
    source_tier = str(article.get("source_tier", "unknown")).lower()
    freshness_unknown = bool(article.get("freshness_unknown", False))
    is_stale_candidate = bool(article.get("is_stale_candidate", False))
    is_old_news = bool(article.get("is_old_news", False))
    content_available = bool(article.get("content_available", False))
    age_hours = article.get("age_hours")

    if is_stale_candidate:
        article["total_score"] = max(0, score - 25)
        article["freshness_status"] = "stale_candidate"
        article["analysis_tier"] = "skip" if article.get("total_score", 0) < min_score + 10 else "basic"
    elif is_old_news:
        article["total_score"] = max(0, score - 15)
        article["freshness_status"] = "old_news"
        if article.get("analysis_tier") == "deep":
            article["analysis_tier"] = "basic"
    elif freshness_unknown and source_tier == "c":
        article["total_score"] = max(0, score - 12)
        article["freshness_status"] = "unknown_weak_source"
        if article.get("analysis_tier") == "deep":
            article["analysis_tier"] = "basic"
    elif freshness_unknown and not content_available:
        article["total_score"] = max(0, score - 10)
        article["freshness_status"] = "unknown_thin_content"
        if article.get("analysis_tier") == "deep":
            article["analysis_tier"] = "basic"
    else:
        article["freshness_status"] = "ok"

    if isinstance(age_hours, (int, float)) and age_hours <= 48 and article["freshness_status"] == "ok":
        article["total_score"] = min(100, int(article.get("total_score", 0) or 0) + 5)
        article["freshness_status"] = "fresh_boost"
        if article.get("analysis_tier") == "basic" and article.get("total_score", 0) >= min_score - 5:
            article["analysis_tier"] = "deep"

    _recompute_relevance_level(article)


def _articles_same_event(left: dict[str, Any], right: dict[str, Any]) -> bool:
    left_tokens = _title_tokens(left.get("title", ""))
    right_tokens = _title_tokens(right.get("title", ""))

    if not left_tokens or not right_tokens:
        return False

    intersection = left_tokens & right_tokens
    union = left_tokens | right_tokens
    jaccard = len(intersection) / max(1, len(union))

    if jaccard >= 0.6:
        return True

    # Nếu title overlap đủ mạnh và có ít nhất 3 token chung, coi là cùng event.
    if len(intersection) >= 3 and jaccard >= 0.4:
        return True

    return False


def _event_sort_key(article: dict[str, Any]) -> tuple[int, int, int, int]:
    tier_order = {"a": 3, "b": 2, "c": 1, "unknown": 0}
    return (
        int(article.get("total_score", 0) or 0),
        tier_order.get(str(article.get("source_tier", "unknown")).lower(), 0),
        1 if article.get("content_available") else 0,
        0 if article.get("freshness_unknown") else 1,
    )


def _cluster_events(scored_articles: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    clusters: list[list[dict[str, Any]]] = []

    for article in scored_articles:
        matched_cluster: list[dict[str, Any]] | None = None
        for cluster in clusters:
            representative = cluster[0]
            if _articles_same_event(article, representative):
                matched_cluster = cluster
                break

        if matched_cluster is None:
            clusters.append([article])
        else:
            matched_cluster.append(article)

    return clusters


def _annotate_event_clusters(scored_articles: list[dict[str, Any]], min_score: int) -> list[dict[str, Any]]:
    """
    Gắn metadata event cho từng article và boost nhẹ event có nhiều nguồn đồng thuận.
    """
    clusters = _cluster_events(scored_articles)
    primaries: list[dict[str, Any]] = []

    for idx, cluster in enumerate(clusters, 1):
        cluster.sort(key=_event_sort_key, reverse=True)
        event_id = f"evt_{idx:03d}"
        titles = [str(item.get("title", "")) for item in cluster[:4] if item.get("title")]
        domains = sorted({str(item.get("source_domain", "")) for item in cluster if item.get("source_domain")})
        source_count = len(domains)

        for rank, article in enumerate(cluster, 1):
            article["event_id"] = event_id
            article["event_cluster_size"] = len(cluster)
            article["event_source_count"] = source_count
            article["event_titles"] = titles
            article["event_domains"] = domains
            article["event_is_primary"] = rank == 1
            article["event_consensus"] = source_count >= 2
            article["event_rank"] = rank

        primary = cluster[0]
        event_bonus = min(6, max(0, source_count - 1) * 3)
        if event_bonus:
            primary["total_score"] = min(100, int(primary.get("total_score", 0) or 0) + event_bonus)
            if int(primary.get("total_score", 0) or 0) >= min_score - 5 and primary.get("analysis_tier") == "basic":
                primary["analysis_tier"] = "deep"
            _recompute_relevance_level(primary)
        primaries.append(primary)

    return primaries


def _normalize_primary_type(article: dict[str, Any]) -> None:
    """
    Heuristic hẹp để sửa type ở một số case biên.
    Giữ minimal để không phá kết quả tier vốn đã ổn.
    """
    title = str(article.get("title", "")).lower()
    current_type = str(article.get("primary_type", "Practical"))
    score = int(article.get("total_score", 0) or 0)
    content_available = bool(article.get("content_available", False))

    # Trang danh mục / landing page thiếu nội dung: ép về Practical để dễ hiểu hơn.
    if not content_available and score <= 15:
        if any(token in title for token in ("cập nhật tin", "bao", "báo", "khoa hoc", "khoa học", "cong nghe", "công nghệ")):
            article["primary_type"] = "Practical"
            article["primary_emoji"] = "🛠️"
            return

    # Ecosystem/community stories nên ưu tiên Society, kể cả có chữ "cạnh tranh".
    if "ecosystem" in title or "hệ sinh thái" in title or "he sinh thai" in title:
        if "startup" not in title and "partnership" not in title and "partners with" not in title:
            article["primary_type"] = "Society"
            article["primary_emoji"] = "🌍"
            return

    # Tin về startup/thi trường/cạnh tranh nên nghiêng về Business.
    if any(keyword in title for keyword in BUSINESS_KEYWORDS):
        article["primary_type"] = "Business"
        article["primary_emoji"] = "💼"
        return

    # Tin về hệ sinh thái / cộng đồng / giáo dục / bối cảnh Việt Nam nên nghiêng về Society.
    if any(keyword in title for keyword in SOCIETY_KEYWORDS):
        if current_type not in {"Product", "Business"} and "startup" not in title and "partnership" not in title and "partners with" not in title:
            article["primary_type"] = "Society"
            article["primary_emoji"] = "🌍"


def classify_and_score_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: phân loại + chấm điểm mỗi bài viết.

    Input: new_articles (từ deduplicate)
    Output: scored_articles, top_articles, low_score_articles
    """
    articles = state.get("new_articles", [])
    if not articles:
        logger.info("📭 Không có bài mới để classify.")
        return {
            "scored_articles": [],
            "top_articles": [],
            "low_score_articles": [],
        }

    min_score = int(os.getenv("MIN_DEEP_ANALYSIS_SCORE", "60"))
    max_top = int(os.getenv("MAX_DEEP_ANALYSIS_ARTICLES", "10"))
    max_classify = int(os.getenv("MAX_CLASSIFY_ARTICLES", "8"))
    classify_content_limit = int(os.getenv("CLASSIFY_CONTENT_CHAR_LIMIT", "900"))
    classify_max_tokens = int(os.getenv("CLASSIFY_MAX_TOKENS", "320"))

    llm_articles, held_out_articles = _prepare_classify_candidates(list(articles), max_classify)
    logger.info(
        "🧮 Prefilter giữ %d/%d bài cho 32B classify (held_out=%d, max=%d)",
        len(llm_articles),
        len(articles),
        len(held_out_articles),
        max_classify,
    )
    if llm_articles:
        logger.info(
            "   Top prefilter: %s",
            " | ".join(
                f"{a.get('title', 'N/A')[:42]}[{a.get('prefilter_score', 0)}]"
                for a in llm_articles[:5]
            ),
        )

    scored = []
    total = len(llm_articles)

    for i, article in enumerate(llm_articles, 1):
        title = article.get("title", "N/A")
        logger.info("🏷️  Classify+Score [%d/%d]: %s", i, total, title[:60])

        related_ctx = _build_related_context(article)
        user_prompt = CLASSIFY_SCORE_USER_TEMPLATE.format(
            title=title,
            url=article.get("url", ""),
            source=article.get("source", "Unknown"),
            source_domain=article.get("source_domain", ""),
            published_at=article.get("published_at", article.get("published", "")),
            published_at_source=article.get("published_at_source", "unknown"),
            discovered_at=article.get("discovered_at", article.get("fetched_at", "")),
            age_hours=article.get("age_hours", ""),
            freshness_unknown=article.get("freshness_unknown", False),
            is_stale_candidate=article.get("is_stale_candidate", False),
            source_verified=article.get("source_verified", False),
            content_available=article.get("content_available", False),
            content=(article.get("content", "") or article.get("snippet", ""))[:classify_content_limit],
            related_context=related_ctx,
        )

        try:
            result = run_json_inference(
                CLASSIFY_SCORE_SYSTEM,
                user_prompt,
                max_tokens=classify_max_tokens,
                temperature=0.1,
            )

            if result and isinstance(result, dict):
                try:
                    c1 = int(result.get("c1_score", 0) or 0)
                    c2 = int(result.get("c2_score", 0) or 0)
                    c3 = int(result.get("c3_score", 0) or 0)
                except ValueError:
                    c1, c2, c3 = 0, 0, 0
                    
                analysis_tier = str(result.get("analysis_tier", "")).strip().lower()
                if analysis_tier not in {"deep", "basic", "skip"}:
                    projected_total = c1 + c2 + c3
                    if projected_total >= min_score:
                        analysis_tier = "deep"
                    elif projected_total >= 30:
                        analysis_tier = "basic"
                    else:
                        analysis_tier = "skip"

                article.update({
                    "primary_type": result.get("primary_type", "Practical"),
                    "primary_emoji": result.get("primary_emoji", "🛠️"),
                    "c1_score": c1,
                    "c1_reason": str(result.get("c1_reason", "")),
                    "c2_score": c2,
                    "c2_reason": str(result.get("c2_reason", "")),
                    "c3_score": c3,
                    "c3_reason": str(result.get("c3_reason", "")),
                    "total_score": c1 + c2 + c3,
                    "summary_vi": str(result.get("summary_vi", "")),
                    "editorial_angle": str(result.get("editorial_angle", "")),
                    "analysis_tier": analysis_tier,
                    "tags": result.get("tags", []) if isinstance(result.get("tags"), list) else [],
                    "relevance_level": str(result.get("relevance_level", "Low")),
                })
                _apply_strategic_boost(article, min_score)
                _apply_freshness_penalty(article, min_score)
                _normalize_primary_type(article)
            else:
                logger.warning("⚠️ Model không trả JSON cho '%s'", title[:40])
                article.update({
                    "primary_type": "Practical",
                    "primary_emoji": "🛠️",
                    "total_score": 0,
                    "summary_vi": "",
                    "analysis_tier": "skip",
                })
        except Exception as e:
            logger.error("❌ Classify failed: '%s': %s", title[:40], e)
            article.update({
                "primary_type": "Practical",
                "primary_emoji": "🛠️",
                "total_score": 0,
                "analysis_tier": "skip",
            })

        scored.append(article)

    for article in held_out_articles:
        _held_out_article_fallback(article)
        scored.append(article)

    # Sắp xếp theo score giảm dần
    scored.sort(key=lambda a: a.get("total_score", 0), reverse=True)
    primary_event_articles = _annotate_event_clusters(scored, min_score)
    primary_event_articles.sort(key=lambda a: a.get("total_score", 0), reverse=True)

    # Chỉ deep-dive 1 bài đại diện cho mỗi event để tránh lãng phí reasoning.
    top = [
        a for a in primary_event_articles
        if a.get("total_score", 0) >= min_score or a.get("analysis_tier") == "deep"
    ][:max_top]
    low = [a for a in scored if a not in top]

    logger.info(
        "✅ Classify+Score xong: %d bài / %d event → %d top (≥%d) + %d low",
        len(scored), len(primary_event_articles), len(top), min_score, len(low)
    )

    return {
        "scored_articles": scored,
        "top_articles": top,
        "low_score_articles": low,
    }
