"""
quality_gate.py - Final summary sanity gate before Telegram.

If the LLM summary fails deterministic checks, fall back to a safe digest built
from already-grounded article metadata.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from db import get_history
from editorial_guardrails import (
    build_safe_digest,
    build_safe_digest_messages,
    validate_telegram_messages,
    validate_telegram_summary,
)

logger = logging.getLogger(__name__)


def quality_gate_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    Validate `summary_vn` before it is sent to Telegram.
    """
    final_articles = list(state.get("final_articles", []))
    notion_pages = list(state.get("notion_pages", []))
    summary = str(state.get("summary_vn", "") or "")
    telegram_messages = list(state.get("telegram_messages", []) or [])
    history_articles = get_history(days=3, limit=80)
    validation_articles = final_articles + history_articles

    if telegram_messages:
        warnings = validate_telegram_messages(telegram_messages, validation_articles, notion_pages)
    else:
        warnings = validate_telegram_summary(summary, validation_articles, notion_pages)

    if warnings or not summary.strip():
        safe_messages = build_safe_digest_messages(
            final_articles,
            notion_pages,
            history_articles=history_articles,
            per_type=3,
        )
        safe_summary = build_safe_digest(
            final_articles,
            notion_pages,
            history_articles=history_articles,
        )
        logger.warning("⚠️ Quality gate fallback activated: %s", ", ".join(warnings) or "empty_summary")
        return {
            "summary_vn": safe_summary,
            "telegram_messages": safe_messages or [safe_summary],
            "summary_mode": "safe_fallback",
            "summary_warnings": warnings or ["empty_summary"],
        }

    logger.info("✅ Quality gate passed for %d Telegram messages.", len(telegram_messages) or 1)
    return {
        "summary_vn": summary,
        "telegram_messages": telegram_messages or [summary],
        "summary_mode": state.get("summary_mode", "deterministic_sections"),
        "summary_warnings": [],
    }
