"""
deduplicate.py — LangGraph node: Lọc bài trùng lặp.

Sử dụng 2 tầng dedup:
  1. SQLite (db.py): kiểm tra URL hash — nhanh, chính xác
  2. ChromaDB (memory.py): kiểm tra bài tương tự theo nội dung — thông minh

Quá trình:
  - Đọc raw_articles từ state
  - Loại bỏ bài đã có trong SQLite (theo URL)
  - Với mỗi bài mới, kiểm tra memory xem có bài cùng chủ đề không
  - Nếu có bài cũ cùng chủ đề → gắn thông tin "related_past" để Agent biết
  - Ghi new_articles vào state
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

# Đảm bảo project root nằm trong sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from db import is_duplicate
from memory import recall_similar

logger = logging.getLogger(__name__)


def deduplicate_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    LangGraph node: lọc bài trùng lặp và gắn context lịch sử.

    Input (từ state):
        raw_articles: list bài từ gather_news

    Output (ghi vào state):
        new_articles: list bài chưa từng thấy, kèm related_past
    """
    raw = state.get("raw_articles", [])
    if not raw:
        logger.info("📭 Không có bài viết nào cần lọc.")
        return {"new_articles": []}

    new_articles = []
    dup_count = 0

    for article in raw:
        url = article.get("url", "")
        if not url:
            continue

        if not article.get("is_news_candidate", True):
            logger.info(
                "⏭️ Skip non-news candidate: %s (%s)",
                article.get("title", "N/A")[:60],
                ", ".join(article.get("acquisition_flags", [])) or "unknown",
            )
            continue

        # ── Tầng 1: SQLite URL hash check ───────────────────────────
        if is_duplicate(url):
            dup_count += 1
            continue

        # ── Tầng 2: Memory recall — tìm bài cũ cùng chủ đề ────────
        title = article.get("title", "")
        summary = article.get("summary", article.get("snippet", ""))
        query_text = f"{title} {summary}"

        try:
            similar = recall_similar(query_text, n_results=3)
            # Chỉ giữ bài thực sự tương tự (cosine distance < 0.3)
            related = [
                s for s in similar
                if s.get("distance", 1.0) < 0.3
            ]
            if related:
                article["related_past"] = related
                logger.debug(
                    "🔗 Bài '%s' liên quan đến %d bài cũ",
                    title[:40], len(related)
                )
        except Exception as e:
            logger.debug("Memory recall skipped: %s", e)

        new_articles.append(article)

    logger.info(
        "🔍 Dedup: %d bài gốc → %d bài mới (%d trùng lặp bỏ qua)",
        len(raw), len(new_articles), dup_count
    )

    return {"new_articles": new_articles}
