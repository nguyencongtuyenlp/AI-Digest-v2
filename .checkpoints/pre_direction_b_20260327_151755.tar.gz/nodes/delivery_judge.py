"""
delivery_judge.py - Decide which articles are worthy of Telegram delivery.

This node mixes deterministic rules with an optional LLM judge so the pipeline
can be event-aware, freshness-aware, and less likely to push stale or duplicate
stories into the executive brief.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from editorial_guardrails import build_article_grounding
from mlx_runner import run_json_inference

logger = logging.getLogger(__name__)

DELIVERY_JUDGE_SYSTEM = """Bạn là Delivery Judge cho một sản phẩm AI Daily Digest.
Nhiệm vụ: quyết định bài nào xứng đáng xuất hiện trong bản brief Telegram buổi sáng.

Tiêu chí:
- Ưu tiên bài mới, có bằng chứng tốt, có giá trị quyết định với founder/operator/team AI.
- Tránh bài stale, thiếu freshness, thiếu nội dung, hoặc trùng event với bài mạnh hơn.
- Không chọn bài chỉ vì nghe thú vị; phải có ích thực tế.

Trả về JSON:
{
  "groundedness_score": 0-5,
  "freshness_score": 0-5,
  "operator_value_score": 0-5,
  "decision": "include|review|skip",
  "rationale": "1 câu ngắn"
}
"""

DELIVERY_JUDGE_USER_TEMPLATE = """Hãy chấm bài sau cho Telegram brief:

Tiêu đề: {title}
Type: {primary_type}
Score: {total_score}/100
Source: {source}
Source tier: {source_tier}
Published_at: {published_at}
Published_at_source: {published_at_source}
Freshness_unknown: {freshness_unknown}
Is_stale_candidate: {is_stale_candidate}
Content_available: {content_available}
Event_cluster_size: {event_cluster_size}
Event_is_primary: {event_is_primary}
Confidence label: {confidence_label}
Grounding note: {grounding_note}
Short note: {note_summary_vi}
Unknowns:
{unknowns}

Trả về JSON đúng format."""


def _deterministic_delivery_assessment(article: dict[str, Any]) -> dict[str, Any]:
    score = int(article.get("total_score", 0) or 0)
    source_tier = str(article.get("source_tier", "unknown")).lower()
    confidence = str(article.get("confidence_label", "low")).lower()
    content_available = bool(article.get("content_available", False))
    freshness_unknown = bool(article.get("freshness_unknown", False))
    is_stale_candidate = bool(article.get("is_stale_candidate", False))
    is_old_news = bool(article.get("is_old_news", False))
    freshness_bucket = str(article.get("freshness_bucket", "unknown")).lower()
    age_hours = article.get("age_hours")
    event_is_primary = bool(article.get("event_is_primary", True))
    event_cluster_size = int(article.get("event_cluster_size", 1) or 1)

    groundedness_score = 4 if confidence == "high" else 3 if confidence == "medium" else 2
    freshness_score = 0 if is_stale_candidate else 2 if freshness_unknown else 4
    operator_value_score = 4 if score >= 70 else 3 if score >= 50 else 2 if score >= 35 else 1

    if event_cluster_size >= 2:
        groundedness_score = min(5, groundedness_score + 1)
        operator_value_score = min(5, operator_value_score + 1)

    if not event_is_primary:
        return {
            "groundedness_score": groundedness_score,
            "freshness_score": freshness_score,
            "operator_value_score": operator_value_score,
            "decision": "skip",
            "rationale": "Bài này trùng event với một bài mạnh hơn trong cùng batch.",
        }

    if is_stale_candidate:
        decision = "review" if source_tier == "a" and score >= 80 else "skip"
        return {
            "groundedness_score": groundedness_score,
            "freshness_score": freshness_score,
            "operator_value_score": operator_value_score,
            "decision": decision,
            "rationale": "Bài có dấu hiệu cũ, chỉ nên giữ nếu thật sự là nguồn mạnh và còn giá trị quyết định.",
        }

    if is_old_news or freshness_bucket in {"aging", "stale"}:
        decision = "review" if source_tier == "a" and score >= 75 and confidence != "low" else "skip"
        return {
            "groundedness_score": groundedness_score,
            "freshness_score": 1 if decision == "review" else 0,
            "operator_value_score": operator_value_score,
            "decision": decision,
            "rationale": (
                "Bài không còn đủ mới cho brief buổi sáng, chỉ giữ nếu là nguồn mạnh và vẫn còn giá trị quyết định."
            ),
        }

    if freshness_unknown and source_tier == "c":
        return {
            "groundedness_score": groundedness_score,
            "freshness_score": freshness_score,
            "operator_value_score": operator_value_score,
            "decision": "skip",
            "rationale": "Nguồn yếu và không rõ độ mới, không phù hợp để lên brief.",
        }

    if score < 35 or (confidence == "low" and not content_available):
        return {
            "groundedness_score": groundedness_score,
            "freshness_score": freshness_score,
            "operator_value_score": operator_value_score,
            "decision": "skip",
            "rationale": "Tín hiệu yếu hoặc thiếu bằng chứng để chiếm chỗ trong brief.",
        }

    if isinstance(age_hours, (int, float)) and age_hours <= 72:
        freshness_score = min(5, freshness_score + 1)

    avg = (groundedness_score + freshness_score + operator_value_score) / 3
    decision = "include" if avg >= 3.3 and score >= 45 else "review" if avg >= 2.8 else "skip"
    rationale = "Đủ mạnh để đưa vào brief." if decision == "include" else "Nên review thêm trước khi đưa vào brief."

    return {
        "groundedness_score": groundedness_score,
        "freshness_score": freshness_score,
        "operator_value_score": operator_value_score,
        "decision": decision,
        "rationale": rationale,
    }


def _merge_judge_result(article: dict[str, Any], base: dict[str, Any], judged: dict[str, Any] | None) -> None:
    result = dict(base)
    if isinstance(judged, dict):
        try:
            result["groundedness_score"] = int(judged.get("groundedness_score", base["groundedness_score"]))
            result["freshness_score"] = int(judged.get("freshness_score", base["freshness_score"]))
            result["operator_value_score"] = int(judged.get("operator_value_score", base["operator_value_score"]))
        except (TypeError, ValueError):
            pass

        decision = str(judged.get("decision", base["decision"])).strip().lower()
        if decision in {"include", "review", "skip"}:
            result["decision"] = decision
        rationale = str(judged.get("rationale", "")).strip()
        if rationale:
            result["rationale"] = rationale

    article["groundedness_score"] = max(0, min(5, int(result["groundedness_score"])))
    article["freshness_score"] = max(0, min(5, int(result["freshness_score"])))
    article["operator_value_score"] = max(0, min(5, int(result["operator_value_score"])))
    article["delivery_decision"] = result["decision"]
    article["delivery_rationale"] = result["rationale"]
    article["delivery_score"] = (
        article["groundedness_score"] + article["freshness_score"] + article["operator_value_score"]
    )


def delivery_judge_node(state: dict[str, Any]) -> dict[str, Any]:
    final_articles = list(state.get("final_articles", []))
    if not final_articles:
        return {"telegram_candidates": []}

    reviewed_articles: list[dict[str, Any]] = []
    for index, article in enumerate(final_articles, 1):
        grounding = article if article.get("grounding_note") else build_article_grounding(article)
        article.update(grounding)
        base = _deterministic_delivery_assessment(article)

        judged: dict[str, Any] | None = None
        should_call_judge = base["decision"] != "skip" and bool(article.get("event_is_primary", True))
        if should_call_judge:
            logger.info("🧪 Delivery Judge [%d/%d]: %s", index, len(final_articles), article.get("title", "N/A")[:60])
            try:
                judged = run_json_inference(
                    DELIVERY_JUDGE_SYSTEM,
                    DELIVERY_JUDGE_USER_TEMPLATE.format(
                        title=article.get("title", "N/A"),
                        primary_type=article.get("primary_type", "Unknown"),
                        total_score=article.get("total_score", 0),
                        source=article.get("source", "Unknown"),
                        source_tier=article.get("source_tier", "unknown"),
                        published_at=article.get("published_at", ""),
                        published_at_source=article.get("published_at_source", "unknown"),
                        freshness_unknown=article.get("freshness_unknown", False),
                        is_stale_candidate=article.get("is_stale_candidate", False),
                        content_available=article.get("content_available", False),
                        event_cluster_size=article.get("event_cluster_size", 1),
                        event_is_primary=article.get("event_is_primary", True),
                        confidence_label=grounding.get("confidence_label", "low"),
                        grounding_note=grounding.get("grounding_note", ""),
                        note_summary_vi=article.get("note_summary_vi", ""),
                        unknowns=grounding.get("unknowns_text", "- Không có unknown lớn từ metadata."),
                    ),
                    max_tokens=250,
                    temperature=0.1,
                )
            except Exception as exc:
                logger.debug("Delivery judge fallback for '%s': %s", article.get("title", "")[:50], exc)

        _merge_judge_result(article, base, judged)
        reviewed_articles.append(article)

    telegram_candidates = sorted(
        [
            article for article in reviewed_articles
            if article.get("delivery_decision") == "include"
        ],
        key=lambda item: (
            int(item.get("delivery_score", 0) or 0),
            int(item.get("total_score", 0) or 0),
            int(item.get("event_source_count", 1) or 1),
        ),
        reverse=True,
    )[:6]

    logger.info(
        "✅ Delivery judge xong: %d include / %d total",
        len(telegram_candidates),
        len(reviewed_articles),
    )
    return {
        "final_articles": reviewed_articles,
        "telegram_candidates": telegram_candidates,
    }
