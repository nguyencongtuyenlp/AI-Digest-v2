"""
normalize_source.py — LangGraph node: Source verification + date normalization.

Mục tiêu:
- Chuẩn hóa thời gian xuất bản về `published_at` (ISO-8601, UTC) để scoring timeliness ổn định.
- Trích xuất domain để model + hệ thống hiểu độ uy tín nguồn.
- Gắn cờ `source_verified` và `source_tier` bằng heuristic (không phải fact-check tuyệt đối).
- Không dùng `fetched_at` để giả làm `published_at`, nhằm tránh kéo bài cũ thành bài mới.
"""

from __future__ import annotations

import logging
import re
import sys
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

logger = logging.getLogger(__name__)


# Domain tiers (heuristic) — ưu tiên các nguồn tin/tech uy tín.
TIER_A = {
    "reuters.com",
    "apnews.com",
    "bloomberg.com",
    "wsj.com",
    "ft.com",
    "economist.com",
    "nature.com",
    "science.org",
    "arxiv.org",
    "openai.com",
    "anthropic.com",
    "deepmind.google",
    "blog.google",
    "ai.googleblog.com",
    "github.com",
    "huggingface.co",
    "techcrunch.com",
    "theverge.com",
    "arstechnica.com",
    "cnbc.com",
}

TIER_B = {
    "vnexpress.net",
    "vietnamnet.vn",
    "vtv.vn",
    "genk.vn",
    "nhandan.vn",
}

NON_NEWS_DOMAINS = {
    "bing.com",
    "search.yahoo.com",
    "yahoo.com",
    "doubleclick.net",
    "googleadservices.com",
    "dichvucong.gov.vn",
}

NON_NEWS_URL_PATTERNS = (
    "aclick",
    "/search?",
    "/search;",
    "/ads/",
    "/p/home/",
    "/home/dvc-",
)

ARTICLE_HINTS = ("/news/", "/blog/", "/posts/", "/article", "/press", "/stories/")


def _domain_from_url(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
    except Exception:
        return ""
    if netloc.startswith("www."):
        netloc = netloc[4:]
    return netloc


def _parse_datetime(value: str) -> datetime | None:
    """
    Parse các định dạng phổ biến vào datetime có timezone.
    Trả None nếu không parse được.
    """
    if not value:
        return None
    v = value.strip()

    # ISO-8601 (RSS node đã dùng)
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        pass

    # RFC 2822 (feedparser đôi khi dùng)
    try:
        dt = parsedate_to_datetime(v)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        pass

    # Một vài format hay gặp
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y %H:%M", "%d/%m/%Y"):
        try:
            dt = datetime.strptime(v, fmt)
            return dt.replace(tzinfo=timezone.utc)
        except Exception:
            continue

    return None


def _parse_datetime_from_url(url: str) -> datetime | None:
    if not url:
        return None

    lowered = url.lower()

    match = re.search(r"/(20\d{2})/(0[1-9]|1[0-2])/(0[1-9]|[12]\d|3[01])(?:/|$)", lowered)
    if match:
        year, month, day = map(int, match.groups())
        try:
            return datetime(year, month, day, tzinfo=timezone.utc)
        except ValueError:
            return None

    for raw in re.findall(r"\d{6,}", lowered):
        for start in range(0, max(1, len(raw) - 5)):
            chunk6 = raw[start:start + 6]
            if len(chunk6) == 6:
                year = int(chunk6[:2])
                month = int(chunk6[2:4])
                day = int(chunk6[4:6])
                if 20 <= year <= 39:
                    try:
                        return datetime(2000 + year, month, day, tzinfo=timezone.utc)
                    except ValueError:
                        pass

            chunk8 = raw[start:start + 8]
            if len(chunk8) == 8 and chunk8.startswith("20"):
                try:
                    return datetime.strptime(chunk8, "%Y%m%d").replace(tzinfo=timezone.utc)
                except ValueError:
                    pass

    return None


def _freshness_bucket(age_hours: float | None) -> str:
    if age_hours is None:
        return "unknown"
    if age_hours <= 24:
        return "breaking"
    if age_hours <= 72:
        return "fresh"
    if age_hours <= 7 * 24:
        return "recent"
    if age_hours <= 30 * 24:
        return "aging"
    return "stale"


def _looks_like_news_candidate(domain: str, url: str, title: str) -> tuple[bool, list[str]]:
    lowered_url = str(url or "").lower()
    lowered_title = str(title or "").lower().strip()
    flags: list[str] = []

    if domain in NON_NEWS_DOMAINS:
        flags.append("blocked_domain")

    if any(pattern in lowered_url for pattern in NON_NEWS_URL_PATTERNS):
        flags.append("search_or_landing_url")

    if domain in {"aws.amazon.com", "cloud.google.com"} and not any(hint in lowered_url for hint in ARTICLE_HINTS):
        flags.append("vendor_landing_page")

    if lowered_title in {"xai", "cổng dịch vụ công quốc gia"}:
        flags.append("generic_or_offscope_title")

    if "trusted by" in lowered_title or "get started" in lowered_title:
        flags.append("marketing_title")

    return (not flags), flags


def _tier_for(domain: str) -> str:
    if not domain:
        return "unknown"
    if domain in TIER_A:
        return "a"
    if domain in TIER_B:
        return "b"
    return "c"


def normalize_source_node(state: dict[str, Any]) -> dict[str, Any]:
    """
    Input: raw_articles
    Output: raw_articles (được enrich thêm metadata)
    """
    raw_articles = list(state.get("raw_articles", []))
    if not raw_articles:
        return {"raw_articles": []}

    now = datetime.now(timezone.utc)

    for a in raw_articles:
        url = a.get("url", "") or ""
        domain = a.get("source_domain") or _domain_from_url(url)
        a["source_domain"] = domain

        # published_at chỉ lấy từ metadata nguồn, KHÔNG fallback sang fetched_at
        published_raw = (
            a.get("published_at")
            or a.get("published")
            or a.get("date")
            or ""
        )
        dt = _parse_datetime(str(published_raw)) if published_raw else None
        if dt is None:
            dt = _parse_datetime_from_url(url)
        fetched_raw = a.get("fetched_at", "") or ""
        fetched_dt = _parse_datetime(str(fetched_raw)) if fetched_raw else None

        if dt:
            a["published_at"] = dt.astimezone(timezone.utc).isoformat()
            a["age_hours"] = round((now - dt).total_seconds() / 3600, 2)
            a["published_at_source"] = "source_metadata" if published_raw else "url_pattern"
        else:
            a["published_at"] = ""
            a["age_hours"] = None
            a["published_at_source"] = "unknown"

        if fetched_dt:
            a["discovered_at"] = fetched_dt.astimezone(timezone.utc).isoformat()
        elif fetched_raw:
            a["discovered_at"] = str(fetched_raw)
        else:
            a["discovered_at"] = ""

        a["freshness_unknown"] = not bool(dt)
        a["freshness_bucket"] = _freshness_bucket(a["age_hours"])
        a["is_fresh"] = a["freshness_bucket"] in {"breaking", "fresh"}
        a["is_old_news"] = bool(a["age_hours"] is not None and a["age_hours"] > 7 * 24)
        a["is_stale_candidate"] = bool(dt and (now - dt).total_seconds() > 14 * 24 * 3600)

        # Source verification (heuristic): RSS và domain tier A/B thì coi là "verified"
        source = (a.get("source", "") or "").lower()
        tier = _tier_for(domain)
        a["source_tier"] = tier

        is_rss = source.startswith("rss:")
        verified = bool(is_rss or tier in {"a", "b"})
        a["source_verified"] = verified

        # Flag nếu content rỗng (tín hiệu chất lượng thấp)
        content = (a.get("content", "") or "").strip()
        a["content_available"] = bool(content and len(content) >= 200)

        is_news_candidate, acquisition_flags = _looks_like_news_candidate(
            domain=domain,
            url=url,
            title=a.get("title", ""),
        )
        a["is_news_candidate"] = is_news_candidate
        a["acquisition_flags"] = acquisition_flags

    logger.info("✅ Normalized %d articles (date+domain+verification)", len(raw_articles))
    return {"raw_articles": raw_articles}
