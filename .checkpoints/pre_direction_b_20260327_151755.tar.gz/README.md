# 🤖 Daily Digest Agent

> Pure-local AI Agent chạy trên **Apple Silicon (M4 Pro)** — tự thu thập tin AI/Tech mỗi sáng, phân loại, lưu Notion, tóm tắt và gửi Telegram. **0₫ chi phí API inference.**

## ✨ Features

| Feature | Mô tả |
|---------|--------|
| 🔍 Multi-source gathering | DuckDuckGo (EN + VN) + Telegram channels |
| 🏷️ 6-type classification | Research · Product · Business · Policy · Society · Practical |
| 🧠 Local LLM inference | MLX trên Apple Silicon — Qwen3.5-35B-A3B-Instruct 4-bit |
| 📝 Notion archiving | Tự tạo page với formatted blocks |
| 📱 Telegram delivery | Gửi digest summary tới group/channel |
| 🔁 Deduplication | SQLite URL hashing — không lặp bài |
| ⏰ Auto-schedule | macOS launchd 8:00 sáng mỗi ngày |

## 🏗️ Architecture

```
gather_news → classify_types → save_notion → summarize → send_telegram → END
```

Toàn bộ pipeline dùng **LangGraph StateGraph** với typed state dict.

## 🚀 Cài đặt

### 1. Clone & tạo virtualenv

```bash
cd /Users/quangdang/Projects/daily-digest-agent
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Cấu hình `.env`

```bash
cp config/.env.example config/.env
# Mở config/.env và điền token thật
```

Bạn cần:
- **Notion**: Tạo [Internal Integration](https://www.notion.so/my-integrations), lấy token + share database
- **Telegram Bot**: Tạo bot qua [@BotFather](https://t.me/BotFather), lấy token + chat ID
- **Telethon** (optional): Đăng ký app tại [my.telegram.org](https://my.telegram.org) để đọc channels

### 3. Chạy thủ công

```bash
source .venv/bin/activate
python main.py
```

### 4. Cài launchd (auto 8:00 sáng)

```bash
cp launchd.plist ~/Library/LaunchAgents/com.quangdang.daily-digest-agent.plist
launchctl load ~/Library/LaunchAgents/com.quangdang.daily-digest-agent.plist
```

Kiểm tra:
```bash
launchctl list | grep digest
```

Gỡ:
```bash
launchctl unload ~/Library/LaunchAgents/com.quangdang.daily-digest-agent.plist
```

## 📁 Project Structure

```
daily-digest-agent/
├── main.py                  # Entry point
├── graph.py                 # LangGraph pipeline
├── db.py                    # SQLite deduplication
├── requirements.txt
├── launchd.plist            # macOS scheduler
├── .gitignore
├── config/
│   ├── .env.example         # Environment template
│   └── prompt_daily_digest.md  # Master LLM prompt
├── nodes/
│   ├── __init__.py
│   ├── gather_news.py       # Node 1: Thu thập tin
│   ├── classify_types.py    # Node 2: Phân loại
│   ├── save_notion.py       # Node 3: Lưu Notion
│   ├── summarize.py         # Node 4: Tóm tắt
│   └── send_telegram.py     # Node 5: Gửi Telegram
└── README.md
```

## 🐛 Debug

```bash
# Kiểm tra logs
cat digest.log
cat digest_error.log

# Chạy manually với debug
python main.py 2>&1 | tee debug_output.txt

# Kiểm tra database
python -c "from db import get_history; print(len(get_history()))"
```

## ⚙️ Tùy chỉnh

- **Thêm nguồn tin**: Sửa `SEARCH_QUERIES_EN` / `SEARCH_QUERIES_VN` trong `nodes/gather_news.py`
- **Đổi model**: Sửa `MLX_MODEL` trong `.env`
- **Đổi prompt**: Sửa `config/prompt_daily_digest.md`
- **Đổi giờ chạy**: Sửa `<integer>8</integer>` trong `launchd.plist`


bạn đã hiểu rõ xem tôi và sếp đang càna những tin gì không chưa? Thật ra code chưa chạy xong, tôi cũng chưa rõ quy tắc chấm điểm của bạn vì tôi chưa xem lại hêhem, bây giờ tôi nói sơ qua về công ty tôi nhé, thật ra là đang là 1 nhanh nhỏ của công ty to, sau này mà bán sản phảm ok có doanh thu tốt sẽ mở riêng, sếp rất giỏi, thường xuyên theo dõi các ông lớn công nghệ xem họ có gì, mua cả con mac mini m4 pro 48gb để cho tôi làm dự án này mà, do đó tôi càna phải xây dựng tốt con này để sau này làm cơ sở xây dựngj nhiều con khác nữa , thì sếp rất hay tìm kiếm trên X, rồi một số group Facebook theo dõi các công nghệ mới, rất thích tư duy của anthropic, skill của họ, nói chung là 1 người tìm đủ mọi cách để làm ra sản phẩm làm được thì thôi. Với sản phẩm này, tôi muốn làm sao cho con qwen này có thể hoạt động được như những con chatgpt, claude, grok, vif chúng có thể truy cập gần như rất là nhiều nơi, cái sự thông minh của chúng tôi không thể biết được là phía sau chúng dùng thuật toán gì hay data như nào, có api như nào mà có thể truy cập sâu như vậy, điều này làm tôi thấy bực mình và muốn con qwen này có thể thông minh như chúng, và như anh sếp đã nói là phân tích để chatgpt thinking,nghiên cứu chuyên sâu còn phần chấm điểm relevant score thì như claude sonet 4.6. Do vậy tôi chưa đọc kĩ các keiens trúc, logic của dự án này như nào, nhưng tôi muốn hiện thực hoá nó và có thể hiểu được toàn bộ dự án để báo cáo sếp, bây giờ bạn hiểu tôi rồi, cập nhạta thêm vào memory.md nữa nhé, và trả lời ngắn cho tôi xem so với sức mạnhj thực tế của claude và chatgpt thì giờ mo hình của tôi đang như nào