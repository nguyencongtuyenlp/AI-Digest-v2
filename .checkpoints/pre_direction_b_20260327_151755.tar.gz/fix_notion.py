import httpx

token = "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"
db_id = "32eccb0eac8880709c34e774937d5117"

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json",
    "Notion-Version": "2022-06-28"
}

payload = {
    "properties": {
        "Mức độ phù hợp dự án": {
            "select": {
                "options": [
                    {"name": "High", "color": "green"},
                    {"name": "Medium", "color": "yellow"},
                    {"name": "Low", "color": "red"}
                ]
            }
        }
    }
}

r = httpx.patch(f"https://api.notion.com/v1/databases/{db_id}", headers=headers, json=payload)
print("Notion DB Patch Status:", r.status_code)
if r.status_code == 200:
    print("✅ Đã tạo thành công cột 'Mức độ phù hợp dự án' vào Notion!")
else:
    print("❌ Lỗi:", r.text)

import shutil
from pathlib import Path
db_path = Path.home() / ".daily-digest-agent"
if db_path.exists():
    shutil.rmtree(db_path)
    print("✅ Đã xoá sạch trí nhớ ảo (Local DB), sẵn sàng cắn lại 61 bài báoũ cũ làm mới!")
